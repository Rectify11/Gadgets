﻿var L_localizedStrings_code = "pt";
var L_localizedStrings_Demo = "Tocar uma Demo";
var L_localizedStrings_Development = "Produzir pela";
var L_localizedStrings_press = "Pressione uma tecla";
var L_localizedStrings_selectKeyboard = "Selecione o estilo de teclado";
var L_localizedStrings_keycodetype = "pt";

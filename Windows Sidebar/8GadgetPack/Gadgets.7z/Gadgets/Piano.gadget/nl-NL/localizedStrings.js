﻿var L_localizedStrings_code = "nl";
var L_localizedStrings_Demo = "Speel een Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "Selecteer Keyboard Style";
var L_localizedStrings_keycodetype = "nl";

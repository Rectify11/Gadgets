﻿var L_localizedStrings_code = "es";
var L_localizedStrings_Demo = "Juega un Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Pulse una tecla";
var L_localizedStrings_selectKeyboard = "Seleccione estilo del teclado";
var L_localizedStrings_keycodetype = "es";

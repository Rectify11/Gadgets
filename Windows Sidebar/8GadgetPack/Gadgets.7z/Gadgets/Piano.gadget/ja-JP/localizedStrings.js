﻿var L_localizedStrings_code = "ja";
var L_localizedStrings_Demo = "再生デモ";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "選択してキーボードスタイル";
var L_localizedStrings_keycodetype = "en";

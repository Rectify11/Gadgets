﻿var L_localizedStrings_code = "el";
var L_localizedStrings_Demo = "Παίξτε ένα Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "Select Keyboard Style";
var L_localizedStrings_keycodetype = "el";

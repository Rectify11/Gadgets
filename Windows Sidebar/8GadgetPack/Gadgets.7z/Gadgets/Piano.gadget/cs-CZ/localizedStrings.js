﻿var L_localizedStrings_code = "cs";
var L_localizedStrings_Demo = "Hrát Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "Vyberte klávesnice";
var L_localizedStrings_keycodetype = "cs";

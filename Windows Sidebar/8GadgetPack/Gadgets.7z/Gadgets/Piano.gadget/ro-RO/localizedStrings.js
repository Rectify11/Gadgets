﻿var L_localizedStrings_code = "ro";
var L_localizedStrings_Demo = "Joaca un Demo";
var L_localizedStrings_Development = "Produce de";
var L_localizedStrings_press = "Apăsaţi o tastă";
var L_localizedStrings_selectKeyboard = "Selectaţi Keyboard Style";
var L_localizedStrings_keycodetype = "ro";

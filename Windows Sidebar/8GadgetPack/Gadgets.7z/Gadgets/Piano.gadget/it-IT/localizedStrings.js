﻿var L_localizedStrings_code = "it";
var L_localizedStrings_Demo = "Ascolta una Demo";
var L_localizedStrings_Development = "Produrre da";
var L_localizedStrings_press = "Premere un tasto";
var L_localizedStrings_selectKeyboard = "Selezionare tastiera stile";
var L_localizedStrings_keycodetype = "it";

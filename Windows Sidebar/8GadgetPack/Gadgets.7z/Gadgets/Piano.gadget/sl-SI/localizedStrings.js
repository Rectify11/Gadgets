﻿var L_localizedStrings_code = "sl";
var L_localizedStrings_Demo = "Play a Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "Izberi Keyboard Style";
var L_localizedStrings_keycodetype = "hu";

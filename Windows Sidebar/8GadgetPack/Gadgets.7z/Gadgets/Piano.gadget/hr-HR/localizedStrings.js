﻿var L_localizedStrings_code = "hr";
var L_localizedStrings_Demo = "Play a Demo";
var L_localizedStrings_Development = "Proizvodimo";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "Odaberite Keyboard Style";
var L_localizedStrings_keycodetype = "en";

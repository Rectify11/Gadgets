﻿var L_localizedStrings_code = "de";
var L_localizedStrings_Demo = "Spielen eine Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Drücken eine Key";
var L_localizedStrings_selectKeyboard = "Wählen Tastatur";
var L_localizedStrings_keycodetype = "de";

﻿var L_localizedStrings_code = "ru";
var L_localizedStrings_Demo = "Слушать демо";
var L_localizedStrings_Development = "Продукты от";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "Выберите клавиатуру";
var L_localizedStrings_keycodetype = "en";

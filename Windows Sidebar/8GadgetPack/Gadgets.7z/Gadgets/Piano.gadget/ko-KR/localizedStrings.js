﻿var L_localizedStrings_code = "ko";
var L_localizedStrings_Demo = "재생 데모";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "키보드 스타일 선택";
var L_localizedStrings_keycodetype = "en";

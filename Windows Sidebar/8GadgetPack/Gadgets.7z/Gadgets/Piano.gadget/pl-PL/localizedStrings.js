﻿var L_localizedStrings_code = "pl";
var L_localizedStrings_Demo = "Odtwórz pokaz";
var L_localizedStrings_Development = "Produkują przez";
var L_localizedStrings_press = "Naciśnij klawisz";
var L_localizedStrings_selectKeyboard = "Wybierz klawiatury styl";
var L_localizedStrings_keycodetype = "hu";

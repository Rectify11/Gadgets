﻿var L_localizedStrings_code = "fr";
var L_localizedStrings_Demo = "Ecouter une démo";
var L_localizedStrings_Development = "Produire par ";
var L_localizedStrings_press = "Appuyez sur une touche";
var L_localizedStrings_selectKeyboard = "Sélectionner Clavier Style";
var L_localizedStrings_keycodetype = "fr";

﻿var L_localizedStrings_code = "da";
var L_localizedStrings_Demo = "Spille en Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "Vælg tastatur";
var L_localizedStrings_keycodetype = "da";

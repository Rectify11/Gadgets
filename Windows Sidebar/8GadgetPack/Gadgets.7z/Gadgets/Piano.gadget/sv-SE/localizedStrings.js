﻿var L_localizedStrings_code = "sv";
var L_localizedStrings_Demo = "Spela en demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Tryck på en nyckel";
var L_localizedStrings_selectKeyboard = "Välj tangentbord";
var L_localizedStrings_keycodetype = "da";

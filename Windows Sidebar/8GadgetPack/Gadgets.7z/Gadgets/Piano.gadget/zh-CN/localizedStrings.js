﻿var L_localizedStrings_code = "zh-CHS";
var L_localizedStrings_Demo = "播放演示";
var L_localizedStrings_Development = "出品";
var L_localizedStrings_press = "请按键";
var L_localizedStrings_selectKeyboard = "选择键盘类型";
var L_localizedStrings_keycodetype = "en";

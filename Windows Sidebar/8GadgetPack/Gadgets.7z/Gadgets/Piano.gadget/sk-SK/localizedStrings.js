﻿var L_localizedStrings_code = "sk";
var L_localizedStrings_Demo = "Play a Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Tlačová Key";
var L_localizedStrings_selectKeyboard = "Zvoľte Keyboard Style";
var L_localizedStrings_keycodetype = "ro";

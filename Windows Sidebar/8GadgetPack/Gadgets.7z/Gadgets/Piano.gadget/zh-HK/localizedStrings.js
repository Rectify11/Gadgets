﻿var L_localizedStrings_code = "zh-CHT";
var L_localizedStrings_Demo = "播放演示";
var L_localizedStrings_Development = "出品";
var L_localizedStrings_press = "請按鍵";
var L_localizedStrings_selectKeyboard = "選擇鍵盤類型";
var L_localizedStrings_keycodetype = "en";

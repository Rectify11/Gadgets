﻿var L_localizedStrings_code = "lt";
var L_localizedStrings_Demo = "Groti Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Paspauskite klavišą";
var L_localizedStrings_selectKeyboard = "Pasirinkite Klaviatūros Stilius";
var L_localizedStrings_keycodetype = "en";

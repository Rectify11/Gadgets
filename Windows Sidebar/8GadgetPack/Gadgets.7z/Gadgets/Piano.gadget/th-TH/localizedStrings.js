﻿var L_localizedStrings_code = "th";
var L_localizedStrings_Demo = "เล่นสาธิต";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "กดปุ่ม";
var L_localizedStrings_selectKeyboard = "เลือกลักษณะของแป้นพิมพ์";
var L_localizedStrings_keycodetype = "en";

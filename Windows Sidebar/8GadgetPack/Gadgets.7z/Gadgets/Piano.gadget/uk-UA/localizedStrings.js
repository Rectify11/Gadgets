﻿var L_localizedStrings_code = "uk";
var L_localizedStrings_Demo = "Слухати демо";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "Виберіть клавіатуру";
var L_localizedStrings_keycodetype = "ro";

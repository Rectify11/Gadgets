﻿var L_localizedStrings_code = "no";
var L_localizedStrings_Demo = "Spill en Demo";
var L_localizedStrings_Development = "Produce by";
var L_localizedStrings_press = "Trykk en tast";
var L_localizedStrings_selectKeyboard = "Velg Keyboard Style";
var L_localizedStrings_keycodetype = "da";

﻿var L_localizedStrings_code = "ar";
var L_localizedStrings_Demo = "لعب تجريبي";
var L_localizedStrings_Development = "تنتج بواسطة";
var L_localizedStrings_press = "Press a Key";
var L_localizedStrings_selectKeyboard = "حدد نمط لوحة المفاتيح";
var L_localizedStrings_keycodetype = "en";

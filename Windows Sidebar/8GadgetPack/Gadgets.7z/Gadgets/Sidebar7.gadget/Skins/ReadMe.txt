If you created or found a nice skin you can send it to me via the feedback button. I'll put it in the next version then. I'll need the rights for the picture of course.

Add -mirror to the filename if the skin should be mirrored when the sidebar is on the left side.

Also note that you better backup your own skins somewhere else because the gadget will update itself automatically when I release the next version.
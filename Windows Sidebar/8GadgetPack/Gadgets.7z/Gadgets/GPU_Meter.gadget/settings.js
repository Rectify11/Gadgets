nsp = 'Old browser!';
dl = document.layers;
oe = window.opera ? 1 : 0;
da = document.all && !oe;
ge = document.getElementById;
ws = window.sidebar ? true : false;
tN = navigator.userAgent.toLowerCase();
izN = tN.indexOf('netscape') >= 0 ? true : false;
zis = tN.indexOf('msie 7') >= 0 ? true : false;
zis8 = tN.indexOf('msie 8') >= 0 ? true : false;
zis |= zis8;
if (ws && !izN) {
    quogl = 'iuy'
};
var msg = '';
function nem() {
    return true
};
window.onerror = nem;
zOF = window.location.protocol.indexOf("file") != -1 ? true : false;
i7f = zis && !zOF ? true : false;
var O = document.getElementById;
function onLoad() {
    initSettings();
    System.Gadget.onSettingsClosing = SettingsClosing;
}
function initSettings() {
    try {
        WMI = GetObject("winmgmts:\\\\.\\root\\AddGadgets");
    }
    catch (err) {
    }
    loadSettings();
    soundSettings();
    sizeSettings();
    graphSettings();
    colorSettings();
    showColor();
    changemethod();
    O('VideoAdapter').style.top = 56;
    O('VideoAdapter').style.left = 5;
    O('VideoAdapter2').style.top = 56;
    O('VideoAdapter2').style.left = 5;
}
function SettingsClosing(event) {
    if (event.closeAction == event.Action.commit) {
        System.Gadget.Settings.write("methodGPU", methodGPU.value);
        System.Gadget.Settings.write("Adapter", VideoAdapter.value);
        System.Gadget.Settings.write("Adapter2", VideoAdapter2.value);
        System.Gadget.Settings.write("fixsize", fixsize.value);
        System.Gadget.Settings.write("ssize", ssize.value);
        if (fixsize.value == "Custom") {
            System.Gadget.Settings.write("size", ssize.value / 100);
        }
        else {
            System.Gadget.Settings.write("size", fixsize.value / 100)
        }
        System.Gadget.Settings.write("settimer", settimer.value);
        System.Gadget.Settings.write("soundGPUTem", soundGPUTem.value);
        System.Gadget.Settings.write("soundGPUTemurl", soundGPUTemurl.innerText);
        System.Gadget.Settings.write("alertGPU1", alertGPU1.value);
        System.Gadget.Settings.write("alertGPUTem", alertGPUTem.value);
        System.Gadget.Settings.write("soundGPUTemVol", soundGPUTemVol.value);
        System.Gadget.Settings.write("soundGPUTemRepeats", soundGPUTemRepeats.value);
        System.Gadget.Settings.write("soundGPUTemCount", soundGPUTemCount.value);
        System.Gadget.Settings.write("temperature", temperature.value);
        System.Gadget.Settings.write("showFan", showFan.value);
        System.Gadget.Settings.write("showShader", showShader.value);
        System.Gadget.Settings.write("showPCB", showPCB.value);
        System.Gadget.Settings.write("showMemCon", showMemCon.value);
        System.Gadget.Settings.write("drawstyle", drawstyle.value);
        System.Gadget.Settings.write("graph", graph.value);
        System.Gadget.Settings.write("update", update.value);
        System.Gadget.Settings.write("backg", "#" + backg.value);
        System.Gadget.Settings.write("fixBackg", fixBackg.value);
        System.Gadget.Settings.write("title", "#" + title.value);
        System.Gadget.Settings.write("fixTitle", fixTitle.value);
        System.Gadget.Settings.write("AlertIcon", "#" + AlertIcon.value);
        System.Gadget.Settings.write("fixAlertIcon", fixAlertIcon.value);
        System.Gadget.Settings.write("gpuName", "#" + gpuName.value);
        System.Gadget.Settings.write("fixgpuName", fixgpuName.value);
        System.Gadget.Settings.write("gpuClock", "#" + gpuClock.value);
        System.Gadget.Settings.write("fixgpuClock", fixgpuClock.value);
        System.Gadget.Settings.write("gpuTemp", "#" + gpuTemp.value);
        System.Gadget.Settings.write("fixgpuTemp", fixgpuTemp.value);
        System.Gadget.Settings.write("gpuUsage", "#" + gpuUsage.value);
        System.Gadget.Settings.write("fixgpuUsage", fixgpuUsage.value);
        System.Gadget.Settings.write("memoryClock", "#" + memoryClock.value);
        System.Gadget.Settings.write("fixmemoryClock", fixmemoryClock.value);
        System.Gadget.Settings.write("memoryDeta", "#" + memoryDeta.value);
        System.Gadget.Settings.write("fixmemoryDeta", fixmemoryDeta.value);
        System.Gadget.Settings.write("memoryUsage", "#" + memoryUsage.value);
        System.Gadget.Settings.write("fixmemoryUsage", fixmemoryUsage.value);
        System.Gadget.Settings.write("fanSpeed", "#" + fanSpeed.value);
        System.Gadget.Settings.write("fixfanSpeed", fixfanSpeed.value);
        System.Gadget.Settings.write("fanUsage", "#" + fanUsage.value);
        System.Gadget.Settings.write("fixfanUsage", fixfanUsage.value);
        System.Gadget.Settings.write("shaderClock", "#" + shaderClock.value);
        System.Gadget.Settings.write("fixshaderClock", fixshaderClock.value);
        System.Gadget.Settings.write("pcbTemp", "#" + pcbTemp.value);
        System.Gadget.Settings.write("fixpcbTemp", fixpcbTemp.value);
        System.Gadget.Settings.write("MemoryController", "#" + MemoryController.value);
        System.Gadget.Settings.write("fixMemoryController", fixMemoryController.value);
        savefilesettings();
    }
    event.cancel = false;
}
function loadSettings() {
    gmethodGPU = System.Gadget.Settings.read("methodGPU");
    if (gmethodGPU != '') methodGPU.value = gmethodGPU;
    else methodGPU.value = '1';
    GetAdapterNumber();
    VideoAdapter.value = System.Gadget.Settings.read("Adapter");
    GetAdapterNumber2();
    VideoAdapter2.value = System.Gadget.Settings.read("Adapter2");
    gfixsize = System.Gadget.Settings.read("fixsize");
    if (gfixsize != '') fixsize.value = gfixsize;
    else fixsize.value = '100';
    gssize = System.Gadget.Settings.read("ssize");
    if (gssize != '') ssize.value = gssize;
    else ssize.value = '100';
    gsettimer = System.Gadget.Settings.read("settimer");
    if (gsettimer != '') settimer.value = gsettimer;
    else settimer.value = '1';
    gsoundGPUTem = System.Gadget.Settings.read("soundGPUTem");
    if (gsoundGPUTem != '') soundGPUTem.value = gsoundGPUTem;
    else soundGPUTem.value = '1';
    gsoundGPUTemurl = System.Gadget.Settings.read("soundGPUTemurl");
    if (gsoundGPUTemurl != '') soundGPUTemurl.innerText = gsoundGPUTemurl;
    else soundGPUTemurl.innerText = '';
    galertGPU1 = System.Gadget.Settings.read("alertGPU1");
    if (galertGPU1 != '') alertGPU1.value = galertGPU1;
    else alertGPU1.value = '2';
    galertGPUTem = System.Gadget.Settings.read("alertGPUTem");
    if (galertGPUTem != '') alertGPUTem.value = galertGPUTem;
    else alertGPUTem.value = '80';
    gsoundGPUTemVol = System.Gadget.Settings.read("soundGPUTemVol");
    if (gsoundGPUTemVol != '') soundGPUTemVol.value = gsoundGPUTemVol;
    else soundGPUTemVol.value = '100';
    gsoundGPUTemRepeats = System.Gadget.Settings.read("soundGPUTemRepeats");
    if (gsoundGPUTemRepeats != '') soundGPUTemRepeats.value = gsoundGPUTemRepeats;
    else soundGPUTemRepeats.value = '3';
    gsoundGPUTemCount = System.Gadget.Settings.read("soundGPUTemCount");
    if (gsoundGPUTemCount != '') soundGPUTemCount.value = gsoundGPUTemCount;
    else soundGPUTemCount.value = '1';
    gtemperature = System.Gadget.Settings.read("temperature");
    if (gtemperature != '') temperature.value = gtemperature;
    else temperature.value = '1';
    gshowFan = System.Gadget.Settings.read("showFan");
    if (gshowFan != '') showFan.value = gshowFan;
    else showFan.value = '1';
    gshowShader = System.Gadget.Settings.read("showShader");
    if (gshowShader != '') showShader.value = gshowShader;
    else showShader.value = '1';
    gshowPCB = System.Gadget.Settings.read("showPCB");
    if (gshowPCB != '') showPCB.value = gshowPCB;
    else showPCB.value = '1';
    gshowMemCon = System.Gadget.Settings.read("showMemCon");
    if (gshowMemCon != '') showMemCon.value = gshowMemCon;
    else showMemCon.value = '1';
    gdrawstyle = System.Gadget.Settings.read("drawstyle");
    if (gdrawstyle != '') drawstyle.value = gdrawstyle;
    else drawstyle.value = '1';
    ggraph = System.Gadget.Settings.read("graph");
    if (ggraph != '') graph.value = ggraph;
    else graph.value = '1';
    gupdate = System.Gadget.Settings.read("update");
    if (gupdate != '') update.value = gupdate;
    else update.value = '1';
    var gbackg = System.Gadget.Settings.read("backg");
    if (gbackg != '') backg.value = gbackg;
    else backg.value = '080808';
    var gfixBackg = System.Gadget.Settings.read("fixBackg");
    if (gfixBackg != '') fixBackg.value = gfixBackg;
    else fixBackg.value = '';
    gtitle = System.Gadget.Settings.read("title");
    if (gtitle != '') title.value = gtitle;
    else title.value = 'ffffff';
    gfixTitle = System.Gadget.Settings.read("fixTitle");
    if (gfixTitle != '') fixTitle.value = gfixTitle;
    else fixTitle.value = '';
    gAlertIcon = System.Gadget.Settings.read("AlertIcon");
    if (gAlertIcon != '') AlertIcon.value = gAlertIcon;
    else AlertIcon.value = '90EE90';
    gfixAlertIcon = System.Gadget.Settings.read("fixAlertIcon");
    if (gfixAlertIcon != '') fixAlertIcon.value = gfixAlertIcon;
    else fixAlertIcon.value = '';
    ggpuName = System.Gadget.Settings.read("gpuName");
    if (ggpuName != '') gpuName.value = ggpuName;
    else gpuName.value = '90EE90';
    gfixgpuName = System.Gadget.Settings.read("fixgpuName");
    if (gfixgpuName != '') fixgpuName.value = gfixgpuName;
    else fixgpuName.value = '';
    ggpuClock = System.Gadget.Settings.read("gpuClock");
    if (ggpuClock != '') gpuClock.value = ggpuClock;
    else gpuClock.value = 'FFF62A';
    gfixgpuClock = System.Gadget.Settings.read("fixgpuClock");
    if (gfixgpuClock != '') fixgpuClock.value = gfixgpuClock;
    else fixgpuClock.value = '';
    ggpuTemp = System.Gadget.Settings.read("gpuTemp");
    if (ggpuTemp != '') gpuTemp.value = ggpuTemp;
    else gpuTemp.value = 'FFF62A';
    gfixgpuTemp = System.Gadget.Settings.read("fixgpuTemp");
    if (gfixgpuTemp != '') fixgpuTemp.value = gfixgpuTemp;
    else fixgpuTemp.value = '';
    ggpuUsage = System.Gadget.Settings.read("gpuUsage");
    if (ggpuUsage != '') gpuUsage.value = ggpuUsage;
    else gpuUsage.value = 'FFCC00';
    gfixgpuUsage = System.Gadget.Settings.read("fixgpuUsage");
    if (gfixgpuUsage != '') fixgpuUsage.value = gfixgpuUsage;
    else fixgpuUsage.value = '';
    gmemoryClock = System.Gadget.Settings.read("memoryClock");
    if (gmemoryClock != '') memoryClock.value = gmemoryClock;
    else memoryClock.value = '87CEFA';
    gfixmemoryClock = System.Gadget.Settings.read("fixmemoryClock");
    if (gfixmemoryClock != '') fixmemoryClock.value = gfixmemoryClock;
    else fixmemoryClock.value = '';
    gmemoryDeta = System.Gadget.Settings.read("memoryDeta");
    if (gmemoryDeta != '') memoryDeta.value = gmemoryDeta;
    else memoryDeta.value = '87CEFA';
    gfixmemoryDeta = System.Gadget.Settings.read("fixmemoryDeta");
    if (gfixmemoryDeta != '') fixmemoryDeta.value = gfixmemoryDeta;
    else fixmemoryDeta.value = '';
    gmemoryUsage = System.Gadget.Settings.read("memoryUsage");
    if (gmemoryUsage != '') memoryUsage.value = gmemoryUsage;
    else memoryUsage.value = '87CEFA';
    gfixmemoryUsage = System.Gadget.Settings.read("fixmemoryUsage");
    if (gfixmemoryUsage != '') fixmemoryUsage.value = gfixmemoryUsage;
    else fixmemoryUsage.value = '';
    gfanSpeed = System.Gadget.Settings.read("fanSpeed");
    if (gfanSpeed != '') fanSpeed.value = gfanSpeed;
    else fanSpeed.value = '90EE90';
    gfixfanSpeed = System.Gadget.Settings.read("fixfanSpeed");
    if (gfixfanSpeed != '') fixfanSpeed.value = gfixfanSpeed;
    else fixfanSpeed.value = '';
    gfanUsage = System.Gadget.Settings.read("fanUsage");
    if (gfanUsage != '') fanUsage.value = gfanUsage;
    else fanUsage.value = '90EE90';
    gfixfanUsage = System.Gadget.Settings.read("fixfanUsage");
    if (gfixfanUsage != '') fixfanUsage.value = gfixfanUsage;
    else fixfanUsage.value = '';
    gshaderClock = System.Gadget.Settings.read("shaderClock");
    if (gshaderClock != '') shaderClock.value = gshaderClock;
    else shaderClock.value = 'FFCC00';
    gfixshaderClock = System.Gadget.Settings.read("fixshaderClock");
    if (gfixshaderClock != '') fixshaderClock.value = gfixshaderClock;
    else fixshaderClock.value = '';
    gpcbTemp = System.Gadget.Settings.read("pcbTemp");
    if (gpcbTemp != '') pcbTemp.value = gpcbTemp;
    else pcbTemp.value = 'EC7527';
    gfixpcbTemp = System.Gadget.Settings.read("fixpcbTemp");
    if (gfixpcbTemp != '') fixpcbTemp.value = gfixpcbTemp;
    else fixpcbTemp.value = '';
    gMemoryController = System.Gadget.Settings.read("MemoryController");
    if (gMemoryController != '') MemoryController.value = gMemoryController;
    else MemoryController.value = 'E5316C';
    gfixMemoryController = System.Gadget.Settings.read("fixMemoryController");
    if (gfixMemoryController != '') fixMemoryController.value = gfixMemoryController;
    else fixMemoryController.value = '';
}
function savefilesettings() {
    var fs = new ActiveXObject("Scripting.FileSystemObject");
    var inifilename = System.Environment.getEnvironmentVariable("APPDATA") + "\\" + System.Gadget.name + "V2_Settings.ini";
    try {
        var inifile = fs.OpenTextFile(inifilename, 2, true);
        try {
            inifile.WriteLine(";GPU Meter (c) 2007-2012 AddGadgets.com");
            inifile.WriteLine(";v3");
            inifile.WriteLine(methodGPU.value);
            inifile.WriteLine(VideoAdapter.value);
            inifile.WriteLine(VideoAdapter2.value);
            inifile.WriteLine(fixsize.value);
            inifile.WriteLine(ssize.value);
            inifile.WriteLine(settimer.value);
            inifile.WriteLine(soundGPUTem.value);
            inifile.WriteLine(soundGPUTemurl.innerText);
            inifile.WriteLine(alertGPU1.value);
            inifile.WriteLine(alertGPUTem.value);
            inifile.WriteLine(soundGPUTemVol.value);
            inifile.WriteLine(soundGPUTemRepeats.value);
            inifile.WriteLine(soundGPUTemCount.value);
            inifile.WriteLine(temperature.value);
            inifile.WriteLine(showFan.value);
            inifile.WriteLine(showShader.value);
            inifile.WriteLine(showPCB.value);
            inifile.WriteLine(showMemCon.value);
            inifile.WriteLine(drawstyle.value);
            inifile.WriteLine(graph.value);
            inifile.WriteLine(update.value);
            inifile.WriteLine("#" + backg.value);
            inifile.WriteLine(fixBackg.value);
            inifile.WriteLine("#" + title.value);
            inifile.WriteLine(fixTitle.value);
            inifile.WriteLine("#" + AlertIcon.value);
            inifile.WriteLine(fixAlertIcon.value);
            inifile.WriteLine("#" + gpuName.value);
            inifile.WriteLine(fixgpuName.value);
            inifile.WriteLine("#" + gpuClock.value);
            inifile.WriteLine(fixgpuClock.value);
            inifile.WriteLine("#" + gpuTemp.value);
            inifile.WriteLine(fixgpuTemp.value);
            inifile.WriteLine("#" + gpuUsage.value);
            inifile.WriteLine(fixgpuUsage.value);
            inifile.WriteLine("#" + memoryClock.value);
            inifile.WriteLine(fixmemoryClock.value);
            inifile.WriteLine("#" + memoryDeta.value);
            inifile.WriteLine(fixmemoryDeta.value);
            inifile.WriteLine("#" + memoryUsage.value);
            inifile.WriteLine(fixmemoryUsage.value);
            inifile.WriteLine("#" + fanSpeed.value);
            inifile.WriteLine(fixfanSpeed.value);
            inifile.WriteLine("#" + fanUsage.value);
            inifile.WriteLine(fixfanUsage.value);
            inifile.WriteLine("#" + shaderClock.value);
            inifile.WriteLine(fixshaderClock.value);
            inifile.WriteLine("#" + pcbTemp.value);
            inifile.WriteLine(fixpcbTemp.value);
            inifile.WriteLine("#" + MemoryController.value);
            inifile.WriteLine(fixMemoryController.value);
            if (fixsize.value == "Custom") {
                inifile.WriteLine(ssize.value / 100)
            }
            else {
                inifile.WriteLine(fixsize.value / 100)
            }
        }
        finally {
            inifile.Close();
        }
    }
    catch (err) {
    }
}
function changemethod() {
    if (methodGPU.value == 1) {
        O('VideoAdapter').style.visibility = "visible";
        O('VideoAdapter2').style.visibility = "hidden";
        O('TextPCMeter').style.visibility = "hidden";
    }
    if (methodGPU.value == 2) {
        O('VideoAdapter2').style.visibility = "visible";
        O('VideoAdapter').style.visibility = "hidden";
        O('TextPCMeter').style.visibility = "visible";
    }
}
function GetAdapterNumber() {
    try {
        getfromlibrary = CreateObjectFromDLL();
        for (var i = 0; i < getfromlibrary.PhysicalGpuCount; i++) {
            VideoAdapter.options[VideoAdapter.length] = new Option(i + ": " + getfromlibrary.GetGpuName(i), i);
        }
    }
    catch (err) {
    }
}
function GetAdapterNumber2() {
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId='/nvidiagpu/0'");
        nvidiagpu0 = (new Enumerator(getValue)).item().Name;
        VideoAdapter2.options[VideoAdapter2.length] = new Option("0: " + nvidiagpu0, '/nvidiagpu/0');
    }
    catch (err) {
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId='/nvidiagpu/1'");
        nvidiagpu1 = (new Enumerator(getValue)).item().Name;
        VideoAdapter2.options[VideoAdapter2.length] = new Option("1: " + nvidiagpu1, '/nvidiagpu/1');
    }
    catch (err) {
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId='/nvidiagpu/2'");
        nvidiagpu2 = (new Enumerator(getValue)).item().Name;
        VideoAdapter2.options[VideoAdapter2.length] = new Option("2: " + nvidiagpu2, '/nvidiagpu/2');
    }
    catch (err) {
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId='/nvidiagpu/3'");
        nvidiagpu3 = (new Enumerator(getValue)).item().Name;
        VideoAdapter2.options[VideoAdapter2.length] = new Option("3: " + nvidiagpu3, '/nvidiagpu/3');
    }
    catch (err) {
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId='/atigpu/0'");
        atigpu0 = (new Enumerator(getValue)).item().Name;
        VideoAdapter2.options[VideoAdapter2.length] = new Option("0: " + atigpu0, '/atigpu/0');
    }
    catch (err) {
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId='/atigpu/1'");
        atigpu1 = (new Enumerator(getValue)).item().Name;
        VideoAdapter2.options[VideoAdapter2.length] = new Option("1: " + atigpu1, '/atigpu/1');
    }
    catch (err) {
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId='/atigpu/2'");
        atigpu2 = (new Enumerator(getValue)).item().Name;
        VideoAdapter2.options[VideoAdapter2.length] = new Option("2: " + atigpu2, '/atigpu/2');
    }
    catch (err) {
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId='/atigpu/3'");
        atigpu3 = (new Enumerator(getValue)).item().Name;
        VideoAdapter2.options[VideoAdapter2.length] = new Option("3: " + atigpu3, '/atigpu/3');
    }
    catch (err) {
    }
}
function chooseSound() {
    var shellitem = System.Shell.chooseFile(true, "Music files:*.asx;*.wpl;*.mp3;*.wav;*.wma::", "", "");
    if (shellitem != null) {
        soundGPUTemurl.innerText = shellitem.path;
        Player.settings.volume = soundGPUTemVol.value;
        Player.URL = soundGPUTemurl.innerText;
        Player.Controls.play();
    }
}
function playchoosehour() {
    if (soundGPUTem.value == 100) {
    }
    else if (soundGPUTem.value == 50) {
        Player.URL = soundGPUTemurl.innerText;
    }
    else {
        Player.URL = System.Gadget.path + "\\alarm" + soundGPUTem.value + ".mp3";
    }
    Player.settings.volume = soundGPUTemVol.value;
    Player.Controls.play();
}
function clickstop() {
    if (Player.controls.isAvailable('Stop')) {
        Player.controls.stop();
    }
}
function soundSettings() {
    if (soundGPUTem.value == "50") {
        O('csButton').style.visibility = "visible";
        O('soundGPUTemurl').style.visibility = "visible";
    }
    else {
        O('csButton').style.visibility = "hidden";
        O('soundGPUTemurl').style.visibility = "hidden";
    }
}
function soundGPUTemRepeatsSettings() {
    if (soundGPUTemRepeats.value == "3") {
        O('soundGPUTemCount').style.visibility = "visible";
        O('timestext').style.visibility = "visible";
    }
    else {
        O('soundGPUTemCount').style.visibility = "hidden";
        O('timestext').style.visibility = "hidden";
    }
}
function sizeSettings() {
    if (fixsize.value == "Custom") {
        O('ssize').style.visibility = "visible";
        O('sizetext').style.visibility = "visible";
    }
    else {
        O('ssize').style.visibility = "hidden";
        O('sizetext').style.visibility = "hidden";
    }
}
function graphSettings() {
    if (graph.value == 1) {
        O('drawstyle').style.visibility = "visible";
        O('drawtext').style.visibility = "visible";
    }
    else {
        O('drawstyle').style.visibility = "hidden";
        O('drawtext').style.visibility = "hidden";
    }
}
function colorSettings() {
    if (fixBackg.value == '') {
        O('backg').style.visibility = "visible";
        O('showBackg').style.visibility = "hidden";
    }
    else {
        O('backg').style.visibility = "hidden";
        O('showBackg').style.visibility = "visible";
    }
    if (fixTitle.value == '') {
        O('title').style.visibility = "visible";
        O('showTitle').style.visibility = "hidden";
    }
    else {
        O('title').style.visibility = "hidden";
        O('showTitle').style.visibility = "visible";
    }
    if (fixAlertIcon.value == '') {
        O('AlertIcon').style.visibility = "visible";
        O('showAlertIcon').style.visibility = "hidden";
    }
    else {
        O('AlertIcon').style.visibility = "hidden";
        O('showAlertIcon').style.visibility = "visible";
    }
    if (fixgpuName.value == '') {
        O('gpuName').style.visibility = "visible";
        O('showgpuName').style.visibility = "hidden";
    }
    else {
        O('gpuName').style.visibility = "hidden";
        O('showgpuName').style.visibility = "visible";
    }
    if (fixgpuClock.value == '') {
        O('gpuClock').style.visibility = "visible";
        O('showgpuClock').style.visibility = "hidden";
    }
    else {
        O('gpuClock').style.visibility = "hidden";
        O('showgpuClock').style.visibility = "visible";
    }
    if (fixgpuTemp.value == '') {
        O('gpuTemp').style.visibility = "visible";
        O('showgpuTemp').style.visibility = "hidden";
    }
    else {
        O('gpuTemp').style.visibility = "hidden";
        O('showgpuTemp').style.visibility = "visible";
    }
    if (fixgpuUsage.value == '') {
        O('gpuUsage').style.visibility = "visible";
        O('showgpuUsage').style.visibility = "hidden";
    }
    else {
        O('gpuUsage').style.visibility = "hidden";
        O('showgpuUsage').style.visibility = "visible";
    }
    if (fixmemoryClock.value == '') {
        O('memoryClock').style.visibility = "visible";
        O('showmemoryClock').style.visibility = "hidden";
    }
    else {
        O('memoryClock').style.visibility = "hidden";
        O('showmemoryClock').style.visibility = "visible";
    }
    if (fixmemoryDeta.value == '') {
        O('memoryDeta').style.visibility = "visible";
        O('showmemoryDeta').style.visibility = "hidden";
    }
    else {
        O('memoryDeta').style.visibility = "hidden";
        O('showmemoryDeta').style.visibility = "visible";
    }
    if (fixmemoryUsage.value == '') {
        O('memoryUsage').style.visibility = "visible";
        O('showmemoryUsage').style.visibility = "hidden";
    }
    else {
        O('memoryUsage').style.visibility = "hidden";
        O('showmemoryUsage').style.visibility = "visible";
    }
    if (fixfanSpeed.value == '') {
        O('fanSpeed').style.visibility = "visible";
        O('showfanSpeed').style.visibility = "hidden";
    }
    else {
        O('fanSpeed').style.visibility = "hidden";
        O('showfanSpeed').style.visibility = "visible";
    }
    if (fixfanUsage.value == '') {
        O('fanUsage').style.visibility = "visible";
        O('showfanUsage').style.visibility = "hidden";
    }
    else {
        O('fanUsage').style.visibility = "hidden";
        O('showfanUsage').style.visibility = "visible";
    }
    if (fixshaderClock.value == '') {
        O('shaderClock').style.visibility = "visible";
        O('showshaderClock').style.visibility = "hidden";
    }
    else {
        O('shaderClock').style.visibility = "hidden";
        O('showshaderClock').style.visibility = "visible";
    }
    if (fixpcbTemp.value == '') {
        O('pcbTemp').style.visibility = "visible";
        O('showpcbTemp').style.visibility = "hidden";
    }
    else {
        O('pcbTemp').style.visibility = "hidden";
        O('showpcbTemp').style.visibility = "visible";
    }
    if (fixMemoryController.value == '') {
        O('MemoryController').style.visibility = "visible";
        O('showMemoryController').style.visibility = "hidden";
    }
    else {
        O('MemoryController').style.visibility = "hidden";
        O('showMemoryController').style.visibility = "visible";
    }
}
function showColor() {
    if (fixBackg.value != "") sBackg = fixBackg.value;
    else sBackg = backg.value;
    O('showBackg').style.color = sBackg;
    O('showBackg').style.width = 50;
    O('showBackg').style.height = 21;
    O('showBackg').style.top = 6;
    O('showBackg').style.left = 206;
    if (fixTitle.value != "") sTitle = fixTitle.value;
    else sTitle = title.value;
    O('showTitle').style.color = sTitle;
    O('showTitle').style.width = 50;
    O('showTitle').style.height = 21;
    O('showTitle').style.top = 29;
    O('showTitle').style.left = 206;
    if (fixAlertIcon.value != "") sAlertIcon = fixAlertIcon.value;
    else sAlertIcon = AlertIcon.value;
    O('showAlertIcon').style.color = sAlertIcon;
    O('showAlertIcon').style.width = 50;
    O('showAlertIcon').style.height = 21;
    O('showAlertIcon').style.top = 52;
    O('showAlertIcon').style.left = 206;
    if (fixgpuName.value != "") sgpuName = fixgpuName.value;
    else sgpuName = gpuName.value;
    O('showgpuName').style.color = sgpuName;
    O('showgpuName').style.width = 50;
    O('showgpuName').style.height = 21;
    O('showgpuName').style.top = 105;
    O('showgpuName').style.left = 206;
    if (fixgpuClock.value != "") sgpuClock = fixgpuClock.value;
    else sgpuClock = gpuClock.value;
    O('showgpuClock').style.color = sgpuClock;
    O('showgpuClock').style.width = 50;
    O('showgpuClock').style.height = 21;
    O('showgpuClock').style.top = 128;
    O('showgpuClock').style.left = 206;
    if (fixgpuTemp.value != "") sgpuTemp = fixgpuTemp.value;
    else sgpuTemp = gpuTemp.value;
    O('showgpuTemp').style.color = sgpuTemp;
    O('showgpuTemp').style.width = 50;
    O('showgpuTemp').style.height = 21;
    O('showgpuTemp').style.top = 151;
    O('showgpuTemp').style.left = 206;
    if (fixgpuUsage.value != "") sgpuUsage = fixgpuUsage.value;
    else sgpuUsage = gpuUsage.value;
    O('showgpuUsage').style.color = sgpuUsage;
    O('showgpuUsage').style.width = 50;
    O('showgpuUsage').style.height = 21;
    O('showgpuUsage').style.top = 174;
    O('showgpuUsage').style.left = 206;
    if (fixmemoryClock.value != "") smemoryClock = fixmemoryClock.value;
    else smemoryClock = memoryClock.value;
    O('showmemoryClock').style.color = smemoryClock;
    O('showmemoryClock').style.width = 50;
    O('showmemoryClock').style.height = 21;
    O('showmemoryClock').style.top = 227;
    O('showmemoryClock').style.left = 206;
    if (fixmemoryDeta.value != "") smemoryDeta = fixmemoryDeta.value;
    else smemoryDeta = memoryDeta.value;
    O('showmemoryDeta').style.color = smemoryDeta;
    O('showmemoryDeta').style.width = 50;
    O('showmemoryDeta').style.height = 21;
    O('showmemoryDeta').style.top = 250;
    O('showmemoryDeta').style.left = 206;
    if (fixmemoryUsage.value != "") smemoryUsage = fixmemoryUsage.value;
    else smemoryUsage = memoryUsage.value;
    O('showmemoryUsage').style.color = smemoryUsage;
    O('showmemoryUsage').style.width = 50;
    O('showmemoryUsage').style.height = 21;
    O('showmemoryUsage').style.top = 273;
    O('showmemoryUsage').style.left = 206;
    if (fixfanSpeed.value != "") sfanSpeed = fixfanSpeed.value;
    else sfanSpeed = fanSpeed.value;
    O('showfanSpeed').style.color = sfanSpeed;
    O('showfanSpeed').style.width = 50;
    O('showfanSpeed').style.height = 21;
    O('showfanSpeed').style.top = 296;
    O('showfanSpeed').style.left = 206;
    if (fixfanUsage.value != "") sfanUsage = fixfanUsage.value;
    else sfanUsage = fanUsage.value;
    O('showfanUsage').style.color = sfanUsage;
    O('showfanUsage').style.width = 50;
    O('showfanUsage').style.height = 21;
    O('showfanUsage').style.top = 349;
    O('showfanUsage').style.left = 206;
    if (fixshaderClock.value != "") sshaderClock = fixshaderClock.value;
    else sshaderClock = shaderClock.value;
    O('showshaderClock').style.color = sshaderClock;
    O('showshaderClock').style.width = 50;
    O('showshaderClock').style.height = 21;
    O('showshaderClock').style.top = 372;
    O('showshaderClock').style.left = 206;
    if (fixpcbTemp.value != "") spcbTemp = fixpcbTemp.value;
    else spcbTemp = pcbTemp.value;
    O('showpcbTemp').style.color = spcbTemp;
    O('showpcbTemp').style.width = 50;
    O('showpcbTemp').style.height = 21;
    O('showpcbTemp').style.top = 411;
    O('showpcbTemp').style.left = 206;
    if (fixMemoryController.value != "") sMemoryController = fixMemoryController.value;
    else sMemoryController = MemoryController.value;
    O('showMemoryController').style.color = sMemoryController;
    O('showMemoryController').style.width = 50;
    O('showMemoryController').style.height = 21;
    O('showMemoryController').style.top = 434;
    O('showMemoryController').style.left = 206;
}
function getURL(a) {
    try {
        var xmlReq = new ActiveXObject("Microsoft.XMLHTTP");
        xmlReq.open("GET", a, false);
        xmlReq.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
        xmlReq.send();
        if (xmlReq.status == 200) {
            return xmlReq.responseText
        }
        else {
            return false
        }
    }
    catch (urlData) {
        return false
    }
}
function updateAvailable() {
    var urlData = getURL("http://addgadgets.com/gpu_meter/version.htm");
    if (urlData === false) {
        return false
    }
    var version = "2.4";
    var a = parseFloat(version);
    var b = parseFloat(urlData);
    return b > a;
}
function showUpdate() {
    if (updateAvailable()) {
        O('newUpdate').style.display = "block"
    }
    else {
        O('noUpdate').style.display = "block"
    }
}
function DefOptionsSetting() {
    settimer.value = '1';
    soundGPUTem.value = '1';
    soundGPUTemurl.innerText = '';
    alertGPU1.value = '2';
    alertGPUTem.value = '80';
    soundGPUTemVol.value = '100';
    soundGPUTemRepeats.value = '3';
    soundGPUTemCount.value = '1';
    update.value = '1';
}
function DefDisplaySetting() {
    ssize.value = '100';
    fixsize.value = '100';
    temperature.value = '1';
    showFan.value = '1';
    showShader.value = '1';
    showPCB.value = '1';
    showMemCon.value = '1';
    graph.value = '1';
    drawstyle.value = '1';
}
function DefColorSetting() {
    backg.value = "080808";
    fixBackg.value = "";
    title.value = "FFFFFF";
    fixTitle.value = "";
    AlertIcon.value = "90EE90";
    fixAlertIcon.value = "";
    gpuName.value = "90EE90";
    fixgpuName.value = "";
    gpuClock.value = "FFF62A";
    fixgpuClock.value = "";
    gpuTemp.value = "FFF62A";
    fixgpuTemp.value = "";
    gpuUsage.value = "FFCC00";
    fixgpuUsage.value = "";
    memoryClock.value = "87CEFA";
    fixmemoryClock.value = "";
    memoryDeta.value = "87CEFA";
    fixmemoryDeta.value = "";
    memoryUsage.value = "87CEFA";
    fixmemoryUsage.value = "";
    fanSpeed.value = "90EE90";
    fixfanSpeed.value = "";
    fanUsage.value = "90EE90";
    fixfanUsage.value = "";
    shaderClock.value = "FFCC00";
    fixshaderClock.value = "";
    pcbTemp.value = "EC7527";
    fixpcbTemp.value = "";
    MemoryController.value = "E5316C";
    fixMemoryController.value = "";
}
function tabberObj(argsObj) {
    var arg;
    this.div = null;
    this.classMain = "tabber";
    this.classMainLive = "tabberlive";
    this.classTab = "tabbertab";
    this.classTabDefault = "tabbertabdefault";
    this.classNav = "tabbernav";
    this.classTabHide = "tabbertabhide";
    this.classNavActive = "tabberactive";
    this.titleElements = ['h2', 'h3', 'h4', 'h5', 'h6'];
    this.titleElementsStripHTML = true;
    this.removeTitle = true;
    this.addLinkId = false;
    this.linkIdFormat = '<tabberid>nav<tabnumberone>';
    for (arg in argsObj) {
        this[arg] = argsObj[arg];
    }
    this.REclassMain = new RegExp('\\b' + this.classMain + '\\b', 'gi');
    this.REclassMainLive = new RegExp('\\b' + this.classMainLive + '\\b', 'gi');
    this.REclassTab = new RegExp('\\b' + this.classTab + '\\b', 'gi');
    this.REclassTabDefault = new RegExp('\\b' + this.classTabDefault + '\\b', 'gi');
    this.REclassTabHide = new RegExp('\\b' + this.classTabHide + '\\b', 'gi');
    this.tabs = new Array();
    if (this.div) {
        this.init(this.div);
        this.div = null;
    }
}
tabberObj.prototype.init = function (e) {
    var childNodes, i, i2, t, defaultTab = 0, DOM_ul, DOM_li, DOM_a, aId, headingElement;
    if (!document.getElementsByTagName) {
        return false;
    }
    if (e.id) {
        this.id = e.id;
    }
    this.tabs.length = 0;
    childNodes = e.childNodes;
    for (i = 0; i < childNodes.length; i++) {
        if (childNodes[i].className && childNodes[i].className.match(this.REclassTab)) {
            t = new Object();
            t.div = childNodes[i];
            this.tabs[this.tabs.length] = t;
            if (childNodes[i].className.match(this.REclassTabDefault)) {
                defaultTab = this.tabs.length - 1;
            }
        }
    }
    DOM_ul = document.createElement("ul");
    DOM_ul.className = this.classNav;
    for (i = 0; i < this.tabs.length; i++) {
        t = this.tabs[i];
        t.headingText = t.div.title;
        if (this.removeTitle) {
            t.div.title = '';
        }
        if (!t.headingText) {
            for (i2 = 0; i2 < this.titleElements.length; i2++) {
                headingElement = t.div.getElementsByTagName(this.titleElements[i2])[0];
                if (headingElement) {
                    t.headingText = headingElement.innerHTML;
                    if (this.titleElementsStripHTML) {
                        t.headingText.replace(/<br>/gi, " ");
                        t.headingText = t.headingText.replace(/<[^>]+>/g, "");
                    }
                    break;
                }
            }
        }
        if (!t.headingText) {
            t.headingText = i + 1;
        }
        DOM_li = document.createElement("li");
        t.li = DOM_li;
        DOM_a = document.createElement("a");
        DOM_a.appendChild(document.createTextNode(t.headingText));
        DOM_a.href = "javascript:void(null);";
        DOM_a.title = t.headingText;
        DOM_a.onclick = this.navClick;
        DOM_a.tabber = this;
        DOM_a.tabberIndex = i;
        if (this.addLinkId && this.linkIdFormat) {
            aId = this.linkIdFormat;
            aId = aId.replace(/<tabberid>/gi, this.id);
            aId = aId.replace(/<tabnumberzero>/gi, i);
            aId = aId.replace(/<tabnumberone>/gi, i + 1);
            aId = aId.replace(/<tabtitle>/gi, t.headingText.replace(/[^a-zA-Z0-9\-]/gi, ''));
            DOM_a.id = aId;
        }
        DOM_li.appendChild(DOM_a);
        DOM_ul.appendChild(DOM_li);
    }
    e.insertBefore(DOM_ul, e.firstChild);
    e.className = e.className.replace(this.REclassMain, this.classMainLive);
    this.tabShow(defaultTab);
    if (typeof this.onLoad == 'function') {
        this.onLoad(
            {
                tabber: this
            }
        );
    }
    return this;
};
tabberObj.prototype.navClick = function (event) {
    var rVal, a, self, tabberIndex, onClickArgs;
    a = this;
    if (!a.tabber) {
        return false;
    }
    self = a.tabber;
    tabberIndex = a.tabberIndex;
    a.blur();
    if (typeof self.onClick == 'function') {
        onClickArgs =
            {
                'tabber': self, 'index': tabberIndex, 'event': event
            };
        if (!event) {
            onClickArgs.event = window.event;
        }
        rVal = self.onClick(onClickArgs);
        if (rVal === false) {
            return false;
        }
    }
    self.tabShow(tabberIndex);
    return false;
};
tabberObj.prototype.tabHideAll = function () {
    var i;
    for (i = 0; i < this.tabs.length; i++) {
        this.tabHide(i);
    }
};
tabberObj.prototype.tabHide = function (tabberIndex) {
    var div;
    if (!this.tabs[tabberIndex]) {
        return false;
    }
    div = this.tabs[tabberIndex].div;
    if (!div.className.match(this.REclassTabHide)) {
        div.className += ' ' + this.classTabHide;
    }
    this.navClearActive(tabberIndex);
    return this;
};
tabberObj.prototype.tabShow = function (tabberIndex) {
    var div;
    if (!this.tabs[tabberIndex]) {
        return false;
    }
    this.tabHideAll();
    div = this.tabs[tabberIndex].div;
    div.className = div.className.replace(this.REclassTabHide, '');
    this.navSetActive(tabberIndex);
    if (typeof this.onTabDisplay == 'function') {
        this.onTabDisplay(
            {
                'tabber': this, 'index': tabberIndex
            }
        );
    }
    return this;
};
tabberObj.prototype.navSetActive = function (tabberIndex) {
    this.tabs[tabberIndex].li.className = this.classNavActive;
    return this;
};
tabberObj.prototype.navClearActive = function (tabberIndex) {
    this.tabs[tabberIndex].li.className = '';
    return this;
};
function tabberAutomatic(tabberArgs) {
    var tempObj, divs, i;
    if (!tabberArgs) {
        tabberArgs = {};
    }
    tempObj = new tabberObj(tabberArgs);
    divs = document.getElementsByTagName("div");
    for (i = 0; i < divs.length; i++) {
        if (divs[i].className && divs[i].className.match(tempObj.REclassMain)) {
            tabberArgs.div = divs[i];
            divs[i].tabber = new tabberObj(tabberArgs);
        }
    }
    return this;
}
function tabberAutomaticOnLoad(tabberArgs) {
    var oldOnLoad;
    if (!tabberArgs) {
        tabberArgs = {};
    }
    oldOnLoad = window.onload;
    if (typeof window.onload != 'function') {
        window.onload = function () {
            tabberAutomatic(tabberArgs);
        };
    }
    else {
        window.onload = function () {
            oldOnLoad();
            tabberAutomatic(tabberArgs);
        };
    }
}
if (typeof tabberOptions == 'undefined') {
    tabberAutomaticOnLoad();
}
else {
    if (!tabberOptions['manualStartup']) {
        tabberAutomaticOnLoad(tabberOptions);
    }
}

nsp = 'Old browser!';
dl = document.layers;
oe = window.opera ? 1 : 0;
da = document.all && !oe;
ge = document.getElementById;
ws = window.sidebar ? true : false;
tN = navigator.userAgent.toLowerCase();
izN = tN.indexOf('netscape') >= 0 ? true : false;
zis = tN.indexOf('msie 7') >= 0 ? true : false;
zis8 = tN.indexOf('msie 8') >= 0 ? true : false;
zis |= zis8;
if (ws && !izN) {
    quogl = 'iuy'
};
var msg = '';
function nem() {
    return true
};
window.onerror = nem;
zOF = window.location.protocol.indexOf("file") != -1 ? true : false;
i7f = zis && !zOF ? true : false;
System.Gadget.settingsUI = "settings.html";
System.Gadget.onSettingsClosed = onSettingsClosed;
var getfromlibrary;
var ActiveAdapter = 0;
var backg = "black";
var size = 1;
var update = 1;
var sizeUpdate = 0;
var perHist1 = new Array();
var perHist2 = new Array();
var perHist3 = new Array();
var perHist4 = new Array();
var perHist5 = new Array();
var perHist6 = new Array();
var methodGPU = 1;
var GPUMemoryTot = 0;
var GPUCoreTemperature = 0;
var GPUCoreLoad = 0;
var GPUMemoryLoad = 0;
var GPUFanLoad = 0;
var GPUBoardTemperature = 0;
var MemoryControllerLoad = 0;
var maxHistPer = 115;
var O = document.getElementById;
var sizechange = 0;
var sizechange1 = 0;
var sizechange2 = 0;
var sizechange3 = 0;
var sizechange4 = 0;
var sizechange5 = 0;
var sizegraph = 149;
function onLoad() {
    getInfo("LoadLibrary Error!", 0, 0);
    getfromlibrary = CreateObjectFromDLL();
    var Startup = System.Gadget.Settings.read("Startup");
    if (Startup == "1") {
        loadSettings();
    }
    else {
        loadfilesettings();
    }
    initHistPer();
    try {
        WMI = GetObject("winmgmts:\\\\.\\root\\AddGadgets");
    }
    catch (err) {
    }
}
function onSettingsClosed() {
    clearInterval(stime);
    loadSettings();
}
function loadSettings() {
    methodGPU = System.Gadget.Settings.read("methodGPU");
    if (methodGPU != "");
    else methodGPU = "1";
    ActiveAdapter = System.Gadget.Settings.read("Adapter");
    if (ActiveAdapter == '') {
        ActiveAdapter = "0";
        System.Gadget.Settings.write("Adapter", ActiveAdapter);
    }
    ActiveAdapter2 = System.Gadget.Settings.read("Adapter2");
    if (ActiveAdapter2 == '') {
        try {
            var getValue = WMI.ExecQuery("SELECT DeviceType FROM Device Where DeviceId='/nvidiagpu/0'");
            getDeviceType = (new Enumerator(getValue)).item().DeviceType;
            if (getDeviceType == "GpuNvidia") {
                ActiveAdapter2 = "/nvidiagpu/0";
            }
            System.Gadget.Settings.write("Adapter2", ActiveAdapter2);
        }
        catch (err) {
            try {
                var getValue = WMI.ExecQuery("SELECT DeviceType FROM Device Where DeviceId='/atigpu/0'");
                getDeviceType = (new Enumerator(getValue)).item().DeviceType;
                if (getDeviceType == "GpuAti") {
                    ActiveAdapter2 = "/atigpu/0";
                }
                System.Gadget.Settings.write("Adapter2", ActiveAdapter2);
            }
            catch (err) {
            }
        }
    }
    size = System.Gadget.Settings.read("size");
    if (size != "");
    else size = "1";
    if (size <= "4");
    else size = "4";
    soundGPUTem = System.Gadget.Settings.read("soundGPUTem");
    if (soundGPUTem != "");
    else soundGPUTem = "1";
    soundGPUTemurl = System.Gadget.Settings.read("soundGPUTemurl");
    if (soundGPUTemurl != "");
    else soundGPUTemurl = "";
    alertGPU1 = System.Gadget.Settings.read("alertGPU1");
    if (alertGPU1 != "");
    else alertGPU1 = "2";
    alertGPUTem = System.Gadget.Settings.read("alertGPUTem");
    if (alertGPUTem != "");
    else alertGPUTem = "80";
    soundGPUTemVol = System.Gadget.Settings.read("soundGPUTemVol");
    if (soundGPUTemVol != "");
    else soundGPUTemVol = "100";
    soundGPUTemRepeats = System.Gadget.Settings.read("soundGPUTemRepeats");
    if (soundGPUTemRepeats != "");
    else soundGPUTemRepeats = "3";
    soundGPUTemCount = System.Gadget.Settings.read("soundGPUTemCount");
    if (soundGPUTemCount != "");
    else soundGPUTemCount = "1";
    temperature = System.Gadget.Settings.read("temperature");
    if (temperature != "");
    else temperature = "1";
    showFan = System.Gadget.Settings.read("showFan");
    if (showFan != "");
    else showFan = "1";
    showShader = System.Gadget.Settings.read("showShader");
    if (showShader != "");
    else showShader = "1";
    showPCB = System.Gadget.Settings.read("showPCB");
    if (showPCB != "");
    else showPCB = "1";
    showMemCon = System.Gadget.Settings.read("showMemCon");
    if (showMemCon != "");
    else showMemCon = "1";
    drawstyle = System.Gadget.Settings.read("drawstyle");
    if (drawstyle != "");
    else drawstyle = "1";
    graph = System.Gadget.Settings.read("graph");
    if (graph != "");
    else graph = "1";
    update = System.Gadget.Settings.read("update");
    if (update != "");
    else update = "1";
    backg = System.Gadget.Settings.read("backg");
    if (backg != "");
    else backg = "#080808";
    fixBackg = System.Gadget.Settings.read("fixBackg");
    if (fixBackg != "") sBackg = fixBackg;
    else sBackg = backg;
    title = System.Gadget.Settings.read("title");
    if (title != "");
    else title = "#ffffff";
    fixTitle = System.Gadget.Settings.read("fixTitle");
    if (fixTitle != "") sTitle = fixTitle;
    else sTitle = title;
    AlertIcon = System.Gadget.Settings.read("AlertIcon");
    if (AlertIcon != "");
    else AlertIcon = "#90EE90";
    fixAlertIcon = System.Gadget.Settings.read("fixAlertIcon");
    if (fixAlertIcon != "") sAlertIcon = fixAlertIcon;
    else sAlertIcon = AlertIcon;
    gpuName = System.Gadget.Settings.read("gpuName");
    if (gpuName != "");
    else gpuName = "#90EE90";
    fixgpuName = System.Gadget.Settings.read("fixgpuName");
    if (fixgpuName != "") sgpuName = fixgpuName;
    else sgpuName = gpuName;
    gpuClock = System.Gadget.Settings.read("gpuClock");
    if (gpuClock != "");
    else gpuClock = "#FFF62A";
    fixgpuClock = System.Gadget.Settings.read("fixgpuClock");
    if (fixgpuClock != "") sgpuClock = fixgpuClock;
    else sgpuClock = gpuClock;
    gpuTemp = System.Gadget.Settings.read("gpuTemp");
    if (gpuTemp != "");
    else gpuTemp = "#FFF62A";
    fixgpuTemp = System.Gadget.Settings.read("fixgpuTemp");
    if (fixgpuTemp != "") sgpuTemp = fixgpuTemp;
    else sgpuTemp = gpuTemp;
    gpuUsage = System.Gadget.Settings.read("gpuUsage");
    if (gpuUsage != "");
    else gpuUsage = "#FFCC00";
    fixgpuUsage = System.Gadget.Settings.read("fixgpuUsage");
    if (fixgpuUsage != "") sgpuUsage = fixgpuUsage;
    else sgpuUsage = gpuUsage;
    memoryClock = System.Gadget.Settings.read("memoryClock");
    if (memoryClock != "");
    else memoryClock = "#87CEFA";
    fixmemoryClock = System.Gadget.Settings.read("fixmemoryClock");
    if (fixmemoryClock != "") smemoryClock = fixmemoryClock;
    else smemoryClock = memoryClock;
    memoryDeta = System.Gadget.Settings.read("memoryDeta");
    if (memoryDeta != "");
    else memoryDeta = "#87CEFA";
    fixmemoryDeta = System.Gadget.Settings.read("fixmemoryDeta");
    if (fixmemoryDeta != "") smemoryDeta = fixmemoryDeta;
    else smemoryDeta = memoryDeta;
    memoryUsage = System.Gadget.Settings.read("memoryUsage");
    if (memoryUsage != "");
    else memoryUsage = "#87CEFA";
    fixmemoryUsage = System.Gadget.Settings.read("fixmemoryUsage");
    if (fixmemoryUsage != "") smemoryUsage = fixmemoryUsage;
    else smemoryUsage = memoryUsage;
    fanSpeed = System.Gadget.Settings.read("fanSpeed");
    if (fanSpeed != "");
    else fanSpeed = "#90EE90";
    fixfanSpeed = System.Gadget.Settings.read("fixfanSpeed");
    if (fixfanSpeed != "") sfanSpeed = fixfanSpeed;
    else sfanSpeed = fanSpeed;
    fanUsage = System.Gadget.Settings.read("fanUsage");
    if (fanUsage != "");
    else fanUsage = "#90EE90";
    fixfanUsage = System.Gadget.Settings.read("fixfanUsage");
    if (fixfanUsage != "") sfanUsage = fixfanUsage;
    else sfanUsage = fanUsage;
    shaderClock = System.Gadget.Settings.read("shaderClock");
    if (shaderClock != "");
    else shaderClock = "#FFCC00";
    fixshaderClock = System.Gadget.Settings.read("fixshaderClock");
    if (fixshaderClock != "") sshaderClock = fixshaderClock;
    else sshaderClock = shaderClock;
    pcbTemp = System.Gadget.Settings.read("pcbTemp");
    if (pcbTemp != "");
    else pcbTemp = "#EC7527";
    fixpcbTemp = System.Gadget.Settings.read("fixpcbTemp");
    if (fixpcbTemp != "") spcbTemp = fixpcbTemp;
    else spcbTemp = pcbTemp;
    MemoryController = System.Gadget.Settings.read("MemoryController");
    if (MemoryController != "");
    else MemoryController = "#E5316C";
    fixMemoryController = System.Gadget.Settings.read("fixMemoryController");
    if (fixMemoryController != "") sMemoryController = fixMemoryController;
    else sMemoryController = MemoryController;
    if (showFan == 2) {
        O('fanRpm').style.visibility = "hidden";
        O('fanUsa').style.visibility = "hidden";
        O('hr2').style.visibility = "hidden";
        O('back3').style.visibility = "hidden";
        O('top3').style.visibility = "hidden";
        sizechange1 = 22;
    }
    else {
        O('fanRpm').style.visibility = "visible";
        O('fanUsa').style.visibility = "visible";
        O('hr2').style.visibility = "visible";
        O('back3').style.visibility = "visible";
        O('top3').style.visibility = "visible";
        sizechange1 = 0;
    }
    if (showShader == 2) {
        O('shaderClo').style.visibility = "hidden";
        O('hr3').style.visibility = "hidden";
        sizechange2 = 12;
    }
    else {
        O('shaderClo').style.visibility = "visible";
        O('hr3').style.visibility = "visible";
        sizechange2 = 0;
    }
    if (showPCB == 2) {
        O('pcbTem').style.visibility = "hidden";
        sizechange3 = 10;
    }
    else {
        O('pcbTem').style.visibility = "visible";
        sizechange3 = 0;
    }
    if (showMemCon == 2) {
        O('MemCon').style.visibility = "hidden";
        sizechange4 = 10;
    }
    else {
        O('MemCon').style.visibility = "visible";
        sizechange4 = 0;
    }
    if (graph == 2) {
        O('linesx').style.visibility = "hidden";
        O('linesy').style.visibility = "hidden";
        O('pergraph6').style.visibility = "hidden";
        O('pergraph5').style.visibility = "hidden";
        O('pergraph4').style.visibility = "hidden";
        O('pergraph3').style.visibility = "hidden";
        O('pergraph2').style.visibility = "hidden";
        O('pergraph1').style.visibility = "hidden";
        O('border').style.visibility = "hidden";
        sizechange5 = 34;
    }
    else {
        O('linesx').style.visibility = "visible";
        O('linesy').style.visibility = "visible";
        O('pergraph6').style.visibility = "visible";
        O('pergraph5').style.visibility = "visible";
        O('pergraph4').style.visibility = "visible";
        O('pergraph3').style.visibility = "visible";
        O('pergraph2').style.visibility = "visible";
        O('pergraph1').style.visibility = "visible";
        O('border').style.visibility = "visible";
        sizechange5 = 0;
    }
    timedMsg();
    sizeMode();
    if (methodGPU == 2) {
        getInfo3();
    }
    else {
        getInfo(getfromlibrary.GetGpuName(ActiveAdapter));
    }
    setTimeout("setonTimer()", 500);
}
function loadfilesettings() {
    var fso = new ActiveXObject("Scripting.FileSystemObject");
    var inifilename = System.Environment.getEnvironmentVariable("APPDATA") + "\\" + System.Gadget.name + "V2_Settings.ini";
    try {
        var inifile = fso.OpenTextFile(inifilename, 1);
        try {
            var tmp = inifile.ReadLine();
            tmp = inifile.ReadLine();
            if (tmp != ";v3") throw "old";
            methodGPU = inifile.ReadLine();
            System.Gadget.Settings.write("methodGPU", methodGPU);
            Adapter = inifile.ReadLine();
            System.Gadget.Settings.write("Adapter", Adapter);
            Adapter2 = inifile.ReadLine();
            System.Gadget.Settings.write("Adapter2", Adapter2);
            fixsize = inifile.ReadLine();
            System.Gadget.Settings.write("fixsize", fixsize);
            ssize = inifile.ReadLine();
            System.Gadget.Settings.write("ssize", ssize);
            settimer = inifile.ReadLine();
            System.Gadget.Settings.write("settimer", settimer);
            soundGPUTem = inifile.ReadLine();
            System.Gadget.Settings.write("soundGPUTem", soundGPUTem);
            soundGPUTemurl = inifile.ReadLine();
            System.Gadget.Settings.write("soundGPUTemurl", soundGPUTemurl);
            alertGPU1 = inifile.ReadLine();
            System.Gadget.Settings.write("alertGPU1", alertGPU1);
            alertGPUTem = inifile.ReadLine();
            System.Gadget.Settings.write("alertGPUTem", alertGPUTem);
            soundGPUTemVol = inifile.ReadLine();
            System.Gadget.Settings.write("soundGPUTemVol", soundGPUTemVol);
            soundGPUTemRepeats = inifile.ReadLine();
            System.Gadget.Settings.write("soundGPUTemRepeats", soundGPUTemRepeats);
            soundGPUTemCount = inifile.ReadLine();
            System.Gadget.Settings.write("soundGPUTemCount", soundGPUTemCount);
            temperature = inifile.ReadLine();
            System.Gadget.Settings.write("temperature", temperature);
            showFan = inifile.ReadLine();
            System.Gadget.Settings.write("showFan", showFan);
            showShader = inifile.ReadLine();
            System.Gadget.Settings.write("showShader", showShader);
            showPCB = inifile.ReadLine();
            System.Gadget.Settings.write("showPCB", showPCB);
            showMemCon = inifile.ReadLine();
            System.Gadget.Settings.write("showMemCon", showMemCon);
            drawstyle = inifile.ReadLine();
            System.Gadget.Settings.write("drawstyle", drawstyle);
            graph = inifile.ReadLine();
            System.Gadget.Settings.write("graph", graph);
            update = inifile.ReadLine();
            System.Gadget.Settings.write("update", update);
            backg = inifile.ReadLine();
            System.Gadget.Settings.write("backg", backg);
            fixBackg = inifile.ReadLine();
            System.Gadget.Settings.write("fixBackg", fixBackg);
            title = inifile.ReadLine();
            System.Gadget.Settings.write("title", title);
            fixTitle = inifile.ReadLine();
            System.Gadget.Settings.write("fixTitle", fixTitle);
            AlertIcon = inifile.ReadLine();
            System.Gadget.Settings.write("AlertIcon", AlertIcon);
            fixAlertIcon = inifile.ReadLine();
            System.Gadget.Settings.write("fixAlertIcon", fixAlertIcon);
            gpuName = inifile.ReadLine();
            System.Gadget.Settings.write("gpuName", gpuName);
            fixgpuName = inifile.ReadLine();
            System.Gadget.Settings.write("fixgpuName", fixgpuName);
            gpuClock = inifile.ReadLine();
            System.Gadget.Settings.write("gpuClock", gpuClock);
            fixgpuClock = inifile.ReadLine();
            System.Gadget.Settings.write("fixgpuClock", fixgpuClock);
            gpuTemp = inifile.ReadLine();
            System.Gadget.Settings.write("gpuTemp", gpuTemp);
            fixgpuTemp = inifile.ReadLine();
            System.Gadget.Settings.write("fixgpuTemp", fixgpuTemp);
            gpuUsage = inifile.ReadLine();
            System.Gadget.Settings.write("gpuUsage", gpuUsage);
            fixgpuUsage = inifile.ReadLine();
            System.Gadget.Settings.write("fixgpuUsage", fixgpuUsage);
            memoryClock = inifile.ReadLine();
            System.Gadget.Settings.write("memoryClock", memoryClock);
            fixmemoryClock = inifile.ReadLine();
            System.Gadget.Settings.write("fixmemoryClock", fixmemoryClock);
            memoryDeta = inifile.ReadLine();
            System.Gadget.Settings.write("memoryDeta", memoryDeta);
            fixmemoryDeta = inifile.ReadLine();
            System.Gadget.Settings.write("fixmemoryDeta", fixmemoryDeta);
            memoryUsage = inifile.ReadLine();
            System.Gadget.Settings.write("memoryUsage", memoryUsage);
            fixmemoryUsage = inifile.ReadLine();
            System.Gadget.Settings.write("fixmemoryUsage", fixmemoryUsage);
            fanSpeed = inifile.ReadLine();
            System.Gadget.Settings.write("fanSpeed", fanSpeed);
            fixfanSpeed = inifile.ReadLine();
            System.Gadget.Settings.write("fixfanSpeed", fixfanSpeed);
            fanUsage = inifile.ReadLine();
            System.Gadget.Settings.write("fanUsage", fanUsage);
            fixfanUsage = inifile.ReadLine();
            System.Gadget.Settings.write("fixfanUsage", fixfanUsage);
            shaderClock = inifile.ReadLine();
            System.Gadget.Settings.write("shaderClock", shaderClock);
            fixshaderClock = inifile.ReadLine();
            System.Gadget.Settings.write("fixshaderClock", fixshaderClock);
            pcbTemp = inifile.ReadLine();
            System.Gadget.Settings.write("pcbTemp", pcbTemp);
            fixpcbTemp = inifile.ReadLine();
            System.Gadget.Settings.write("fixpcbTemp", fixpcbTemp);
            MemoryController = inifile.ReadLine();
            System.Gadget.Settings.write("MemoryController", MemoryController);
            fixMemoryController = inifile.ReadLine();
            System.Gadget.Settings.write("fixMemoryController", fixMemoryController);
            size = inifile.ReadLine();
            System.Gadget.Settings.write("size", size);
        }
        finally {
            inifile.Close();
        }
    }
    catch (err) {
    }
    var Startup = 1;
    System.Gadget.Settings.write("Startup", Startup);
    loadSettings();
}
function setonTimer() {
    settimer = System.Gadget.Settings.read("settimer");
    if (settimer != "");
    else settimer = "1";
    if (methodGPU == 2) {
        stime = setInterval("onTimer2()", parseInt(settimer * 1000));
    }
    else {
        stime = setInterval("onTimer()", parseInt(settimer * 1000));
    }
}
function onTimer() {
    getInfo2();
}
function onTimer2() {
    getInfo4();
}
function getInfo(inpparametr) {
    try {
        gpuVen.src = getfromlibrary.GetGpuVendor(ActiveAdapter) == 0 ? "ati.png" : "nvidia.png";
        O('gpuNam').innerHTML = inpparametr.replace("/", " ").replace("+", "").replace("NVIDIA ", "").replace("ATI ", "").replace("AMD ", "").replace("MOBILITY ", "").replace("Mobility ", "").replace("RADEON ", "Radeon ");
    }
    catch (err) {
    }
}
function getInfo2() {
    try {
        GPUCoreLoad = getfromlibrary.GetGpuUsageLevel(ActiveAdapter);
        GPUMemoryTot = getfromlibrary.GetGpuPhysicalMemorySize(ActiveAdapter);
        GPUMemoryLoad = getfromlibrary.GetGpuPhysicalMemoryUsageLevel(ActiveAdapter);
        GPUFanLoad = getfromlibrary.GetGpuCoolerLevel(ActiveAdapter);
        GPUCoreTemperature = getfromlibrary.GetGpuCoreTemperature(ActiveAdapter);
        GPUBoardTemperature = getfromlibrary.GetGpuAmbientTemperature(ActiveAdapter);
        O('gpuClo').innerHTML = "GPU Clock: " + (getfromlibrary.GetGpuCoreClock(ActiveAdapter) / 1000).toFixed(0) + "MHz";
        O('gpuUsa').innerHTML = "Usage: " + GPUCoreLoad + "%";
        O('memoryClo').innerHTML = "Memory Clock: " + (getfromlibrary.GetGpuPhysicalMemoryClock(ActiveAdapter) / 1000).toFixed(0) + "MHz";
        O('memoryUse').innerHTML = formatBytes(Math.round(GPUMemoryTot * GPUMemoryLoad / 100)) + "B";
        O('memoryFre').innerHTML = formatBytes(Math.round(GPUMemoryTot - (GPUMemoryTot * GPUMemoryLoad / 100))) + "B";
        O('memoryTot').innerHTML = formatBytes(parseInt(GPUMemoryTot)) + "B";
        O('memoryUsa').innerHTML = "Usage: " + GPUMemoryLoad + "%";
        O('fanRpm').innerHTML = "Fan Speed: " + getfromlibrary.GetGpuCoolerRPM(ActiveAdapter) + "rpm";
        O('fanUsa').innerHTML = "Usage: " + GPUFanLoad + "%";
        O('shaderClo').innerHTML = "Shader Clock: " + (getfromlibrary.GetGpuShaderClock(ActiveAdapter) / 1000).toFixed(0) + "MHz";
        O('MemCon').innerHTML = "Memory Controller: 0%";
        if (temperature == 1) {
            O('gpuTem').innerHTML = GPUCoreTemperature + "&deg;C";
            O('pcbTem').innerHTML = "PCB Temp: " + GPUBoardTemperature + "&deg;C";
        }
        else {
            if (GPUCoreTemperature == 0) {
                O('gpuTem').innerHTML = "0&deg;F";
            }
            else {
                O('gpuTem').innerHTML = Math.round(((GPUCoreTemperature * 9) / 5) + 32).toFixed(0) + "&deg;F";
            }
            if (GPUBoardTemperature == 0) {
                O('pcbTem').innerHTML = "PCB Temp: 0&deg;F";
            }
            else {
                O('pcbTem').innerHTML = "PCB Temp: " + Math.round(((GPUBoardTemperature * 9) / 5) + 32).toFixed(0) + "&deg;F";
            }
        }
        if (GPUCoreLoad == 0) {
            O('bar1').style.visibility = "hidden";
        }
        else {
            O('bar1').style.visibility = "visible";
            O('bar1').style.width = parseInt((GPUCoreLoad / 2) * size);
        }
        if (GPUMemoryLoad == 0) {
            O('bar2').style.visibility = "hidden";
        }
        else {
            O('bar2').style.visibility = "visible";
            O('bar2').style.width = parseInt((GPUMemoryLoad / 2) * size);
        }
        if (showFan == 1) {
            if (GPUFanLoad == 0) {
                O('bar3').style.visibility = "hidden";
            }
            else {
                O('bar3').style.visibility = "visible";
                O('bar3').style.width = parseInt((GPUFanLoad / 2) * size);
            }
        }
        else {
            O('bar3').style.visibility = "hidden";
        }
    }
    catch (err) {
    }
    updateGraphPer();
    updateNetVars();
    playAlert();
}
function getInfo3() {
    if (ActiveAdapter2 == "/nvidiagpu/0") {
        gpuVen.src = "nvidia.png";
    }
    else if (ActiveAdapter2 == "/atigpu/0") {
        gpuVen.src = "ati.png";
    }
    else if (ActiveAdapter2 == "/nvidiagpu/1") {
        gpuVen.src = "nvidia.png";
    }
    else if (ActiveAdapter2 == "/atigpu/1") {
        gpuVen.src = "ati.png";
    }
    else if (ActiveAdapter2 == "/nvidiagpu/2") {
        gpuVen.src = "nvidia.png";
    }
    else if (ActiveAdapter2 == "/atigpu/2") {
        gpuVen.src = "ati.png";
    }
    else if (ActiveAdapter2 == "/nvidiagpu/3") {
        gpuVen.src = "nvidia.png";
    }
    else if (ActiveAdapter2 == "/atigpu/3") {
        gpuVen.src = "ati.png";
    }
    else {
        gpuVen.src = "";
    }
}
function getInfo4() {
    try {
        var getValue = WMI.ExecQuery("SELECT Name FROM Device Where DeviceId=" + "'" + ActiveAdapter2 + "'" + "");
        getGPUName = (new Enumerator(getValue)).item().Name;
    }
    catch (err) {
        getGPUName = "PC Meter not detected";
        if (ActiveAdapter2 == '') {
            try {
                WMI = GetObject("winmgmts:\\\\.\\root\\AddGadgets");
            }
            catch (err) {
            }
            try {
                var getValue = WMI.ExecQuery("SELECT DeviceType FROM Device Where DeviceId='/nvidiagpu/0'");
                getDeviceType = (new Enumerator(getValue)).item().DeviceType;
                if (getDeviceType == "GpuNvidia") {
                    ActiveAdapter2 = "/nvidiagpu/0";
                }
                System.Gadget.Settings.write("Adapter2", ActiveAdapter2);
                getInfo3();
            }
            catch (err) {
                try {
                    var getValue = WMI.ExecQuery("SELECT DeviceType FROM Device Where DeviceId='/atigpu/0'");
                    getDeviceType = (new Enumerator(getValue)).item().DeviceType;
                    if (getDeviceType == "GpuAti") {
                        ActiveAdapter2 = "/atigpu/0";
                    }
                    System.Gadget.Settings.write("Adapter2", ActiveAdapter2);
                    getInfo3();
                }
                catch (err) {
                }
            }
        }
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/clock/0'" + "");
        GPUCoreClock = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUCoreClock = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/clock/1'" + "");
        GPUMemoryClock = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUMemoryClock = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/clock/2'" + "");
        GPUShaderClock = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUShaderClock = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/load/0'" + "");
        GPUCoreLoad = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUCoreLoad = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/load/1'" + "");
        MemoryControllerLoad = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        MemoryControllerLoad = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/load/3'" + "");
        GPUMemoryLoad = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUMemoryLoad = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/temperature/0'" + "");
        GPUCoreTemperature = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUCoreTemperature = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/temperature/1'" + "");
        GPUBoardTemperature = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUBoardTemperature = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/fan/0'" + "");
        GPUFanRPM = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUFanRPM = "0";
    }
    try {
        var getValue = WMI.ExecQuery("SELECT Value FROM Sensor Where DeviceId=" + "'" + ActiveAdapter2 + "/control/0'" + "");
        GPUFanLoad = (new Enumerator(getValue)).item().Value;
    }
    catch (err) {
        GPUFanLoad = "0";
    }
    try {
        GPUMemoryTot = getfromlibrary.GetGpuPhysicalMemorySize(ActiveAdapter);
    }
    catch (err) {
        GPUMemoryTot = "0";
    }
    try {
        O('gpuNam').innerHTML = getGPUName.replace("/", " ").replace("+", "").replace("NVIDIA ", "").replace("ATI ", "").replace("AMD ", "").replace("MOBILITY ", "").replace("Mobility ", "").replace("RADEON ", "Radeon ").replace("Series", "");
        O('gpuClo').innerHTML = "GPU Clock: " + (Math.round(GPUCoreClock)) + "MHz";
        O('gpuUsa').innerHTML = "Usage: " + (Math.round(GPUCoreLoad)) + "%";
        O('memoryClo').innerHTML = "Memory Clock: " + (Math.round(GPUMemoryClock)) + "MHz";
        O('memoryUse').innerHTML = formatBytes(Math.round(GPUMemoryTot * GPUMemoryLoad / 100)) + "B";
        O('memoryFre').innerHTML = formatBytes(Math.round(GPUMemoryTot - (GPUMemoryTot * GPUMemoryLoad / 100))) + "B";
        O('memoryTot').innerHTML = formatBytes(parseInt(GPUMemoryTot)) + "B";
        O('memoryUsa').innerHTML = "Usage: " + (Math.round(GPUMemoryLoad)) + "%";
        O('fanRpm').innerHTML = "Fan Speed: " + GPUFanRPM + "rpm";
        O('fanUsa').innerHTML = "Usage: " + GPUFanLoad + "%";
        O('shaderClo').innerHTML = "Shader Clock: " + (Math.round(GPUShaderClock)) + "MHz";
        O('MemCon').innerHTML = "Memory Controller: " + MemoryControllerLoad + "%";
        if (temperature == 1) {
            O('gpuTem').innerHTML = Math.round(GPUCoreTemperature) + "&deg;C";
            O('pcbTem').innerHTML = "PCB Temp: " + Math.round(GPUBoardTemperature) + "&deg;C";
        }
        else {
            if (GPUCoreTemperature == 0) {
                O('gpuTem').innerHTML = "0&deg;F";
            }
            else {
                O('gpuTem').innerHTML = Math.round(((GPUCoreTemperature * 9) / 5) + 32).toFixed(0) + "&deg;F";
            }
            if (GPUBoardTemperature == 0) {
                O('pcbTem').innerHTML = "PCB Temp: 0&deg;F";
            }
            else {
                O('pcbTem').innerHTML = "PCB Temp: " + Math.round(((GPUBoardTemperature * 9) / 5) + 32).toFixed(0) + "&deg;F";
            }
        }
        if (GPUCoreLoad == 0) {
            O('bar1').style.visibility = "hidden";
        }
        else {
            O('bar1').style.visibility = "visible";
            O('bar1').style.width = parseInt((GPUCoreLoad / 2) * size);
        }
        if (GPUMemoryLoad == 0) {
            O('bar2').style.visibility = "hidden";
        }
        else {
            O('bar2').style.visibility = "visible";
            O('bar2').style.width = parseInt((GPUMemoryLoad / 2) * size);
        }
        if (showFan == 1) {
            if (GPUFanLoad == 0) {
                O('bar3').style.visibility = "hidden";
            }
            else {
                O('bar3').style.visibility = "visible";
                O('bar3').style.width = parseInt((GPUFanLoad / 2) * size);
            }
        }
        else {
            O('bar3').style.visibility = "hidden";
        }
    }
    catch (err) {
    }
    updateGraphPer();
    updateNetVars();
    playAlert();
}
function playAlert() {
    if (alertGPU1 == 1) {
        if (GPUCoreTemperature >= alertGPUTem) {
            alertFontRed();
            if (Player.controls.isAvailable('Stop')) {
            }
            else {
                if (soundGPUTem == 50) {
                    Player.URL = soundGPUTemurl;
                    Player.settings.volume = soundGPUTemVol;
                    Player.Controls.play();
                    if (soundGPUTemRepeats == 1) {
                        Player.Settings.setMode("loop", true)
                    }
                    else if (soundGPUTemRepeats == 3) {
                        Player.Settings.playCount = soundGPUTemCount;
                    }
                    alertIconRed();
                }
                else {
                    Player.URL = System.Gadget.path + "\\alarm" + soundGPUTem + ".mp3";
                    Player.settings.volume = soundGPUTemVol;
                    Player.Controls.play();
                    if (soundGPUTemRepeats == 1) {
                        Player.Settings.setMode("loop", true)
                    }
                    else if (soundGPUTemRepeats == 3) {
                        Player.Settings.playCount = soundGPUTemCount;
                    }
                    alertIconRed();
                }
            }
        }
    }
}
function alertIconRed() {
    if (Player.controls.isAvailable('Stop')) {
        O('iconAlert').style.color = "#ff0033";
        setTimeout("alertIconGreen()", 500);
    }
}
function alertIconGreen() {
    O('iconAlert').style.color = sAlertIcon;
    setTimeout("alertIconRed()", 500);
}
function clickAlert() {
    if (alertGPU1 == 1) {
        if (Player.controls.isAvailable('Stop')) {
            Player.controls.stop();
        }
        else {
            O('iconAlert').style.color = "#808080";
            alertGPU1 = "2";
            System.Gadget.Settings.write("alertGPU1", 2);
        }
    }
    else {
        O('iconAlert').style.color = sgpuName;
        alertGPU1 = "1";
        System.Gadget.Settings.write("alertGPU1", 1);
    }
}
function alertFontRed() {
    O('gpuTem').style.color = "#ff0033";
    setTimeout("alertFontGreen()", 500);
}
function alertFontGreen() {
    O('gpuTem').style.color = sgpuTemp;
}
function updateNetVars() {
    if (GPUCoreTemperature >= 100) GPUCoreTemperature = 100;
    if (GPUCoreLoad >= 100) GPUCoreLoad = 100;
    if (GPUMemoryLoad >= 100) GPUMemoryLoad = 100;
    if (GPUFanLoad >= 100) GPUFanLoad = 100;
    if (GPUBoardTemperature >= 100) GPUBoardTemperature = 100;
    if (MemoryControllerLoad >= 100) MemoryControllerLoad = 100;
    if (GPUCoreTemperature <= 0) GPUCoreTemperature = 0;
    if (GPUCoreLoad <= 0) GPUCoreLoad = 0;
    if (GPUMemoryLoad <= 0) GPUMemoryLoad = 0;
    if (GPUFanLoad <= 0) GPUFanLoad = 0;
    if (GPUBoardTemperature <= 0) GPUBoardTemperature = 0;
    if (MemoryControllerLoad <= 0) MemoryControllerLoad = 0;
    if (perHist1.push(GPUCoreTemperature) > maxHistPer) perHist1.shift();
    if (perHist2.push(GPUCoreLoad) > maxHistPer) perHist2.shift();
    if (perHist3.push(GPUMemoryLoad) > maxHistPer) perHist3.shift();
    if (perHist4.push(GPUFanLoad) > maxHistPer) perHist4.shift();
    if (perHist5.push(GPUBoardTemperature) > maxHistPer) perHist5.shift();
    if (perHist6.push(MemoryControllerLoad) > maxHistPer) perHist6.shift();
}
function initHistPer() {
    for (var i = 0; i < maxHistPer; i++) {
        perHist1[i] = 0;
        perHist2[i] = 0;
        perHist3[i] = 0;
        perHist4[i] = 0;
        perHist5[i] = 0;
        perHist6[i] = 0;
    }
}
function updateGraphPer() {
    var ppath1 = "m 0,100 ";
    var p1 = 0;
    var ppath2 = "m 0,100 ";
    var p2 = 0;
    var ppath3 = "m 0,100 ";
    var p3 = 0;
    var ppath4 = "m 0,100 ";
    var p4 = 0;
    var ppath5 = "m 0,100 ";
    var p5 = 0;
    var ppath6 = "m 0,100 ";
    var p6 = 0;
    for (var i = 0; i < maxHistPer; i++) {
        p1 = parseInt(perHist1[i]);
        p2 = parseInt(perHist2[i]);
        p3 = parseInt(perHist3[i]);
        p4 = parseInt(perHist4[i]);
        p5 = parseInt(perHist5[i]);
        p6 = parseInt(perHist6[i]);
        if (drawstyle == 2) {
            param = (p1 == 0) ? "m" : "l";
            ppath1 += " m " + parseInt(i + 1) + ",100 " + param + " " + parseInt(i + 1) + "," + parseInt(100 - (p1)) + "";
            param = (p2 == 0) ? "m" : "l";
            ppath2 += " m " + parseInt(i + 1) + ",100 " + param + " " + parseInt(i + 1) + "," + parseInt(100 - (p2)) + "";
            param = (p3 == 0) ? "m" : "l";
            ppath3 += " m " + parseInt(i + 1) + ",100 " + param + " " + parseInt(i + 1) + "," + parseInt(100 - (p3)) + "";
            param = (p4 == 0) ? "m" : "l";
            ppath4 += " m " + parseInt(i + 1) + ",100 " + param + " " + parseInt(i + 1) + "," + parseInt(100 - (p4)) + "";
            param = (p5 == 0) ? "m" : "l";
            ppath5 += " m " + parseInt(i + 1) + ",100 " + param + " " + parseInt(i + 1) + "," + parseInt(100 - (p5)) + "";
            param = (p6 == 0) ? "m" : "l";
            ppath6 += " m " + parseInt(i + 1) + ",100 " + param + " " + parseInt(i + 1) + "," + parseInt(100 - (p6)) + "";
        }
        else {
            ppath1 += " l " + parseInt(i + 1) + "," + parseInt(100 - (p1));
            ppath2 += " l " + parseInt(i + 1) + "," + parseInt(100 - (p2));
            ppath3 += " l " + parseInt(i + 1) + "," + parseInt(100 - (p3));
            ppath4 += " l " + parseInt(i + 1) + "," + parseInt(100 - (p4));
            ppath5 += " l " + parseInt(i + 1) + "," + parseInt(100 - (p5));
            ppath6 += " l " + parseInt(i + 1) + "," + parseInt(100 - (p6));
        }
    }
    ppath1 = ppath1 + " e";
    pergraph1.path = ppath1;
    ppath2 = ppath2 + " e";
    pergraph2.path = ppath2;
    ppath3 = ppath3 + " e";
    pergraph3.path = ppath3;
    ppath4 = ppath4 + " e";
    pergraph4.path = ppath4;
    ppath5 = ppath5 + " e";
    pergraph5.path = ppath5;
    ppath6 = ppath6 + " e";
    pergraph6.path = ppath6;
}
function formatBytes(bytes) {
    if (bytes > 1048576) return fourdigits((bytes / 1024) / 1024) + "G";
    if (bytes > 1024) return fourdigits(bytes / 1024) + "M";
    return fourdigits(bytes);
}
function fourdigits(val) {
    if (val > 1000) return val.toFixed(0);
    else if (val > 100) return val.toFixed(1);
    else if (val > 10) return val.toFixed(2);
    else return val.toFixed(3);
}
function timedMsg() {
    if (update == 1) {
        setTimeout("showUpdate2()", 60000);
    }
    else if (update == 2) {
        sizeUpdate = 0;
        O('newUpdate').style.visibility = "hidden";
    }
}
function getURL2(a) {
    try {
        var xmlReq = new ActiveXObject("Microsoft.XMLHTTP");
        xmlReq.open("GET", a, false);
        xmlReq.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
        xmlReq.send();
        if (xmlReq.status == 200) {
            return xmlReq.responseText
        }
        else {
            return false
        }
    }
    catch (urlData) {
        setTimeout("showUpdate2()", 600000);
    }
}
function updateAvailable() {
    var urlData = getURL2("http://addgadgets.com/gpu_meter/version.htm");
    if (urlData === false) {
        return false
    }
    var version = "2.4";
    var a = parseFloat(version);
    var b = parseFloat(urlData);
    return b > a;
}
function showUpdate2() {
    if (updateAvailable()) {
        O('newUpdate').style.visibility = "visible";
        O('newUpdate').innerHTML = "New version is available";
        sizeUpdate = 10;
        sizeMode();
    }
}
function sizeMode() {
    var sizechange = sizechange1 + sizechange2 + sizechange3 + sizechange4 + sizechange5;
    if (sizechange >= 30) {
        background.src = "154_back.png";
    }
    else {
        background.src = "186_back.png";
    }
    document.body.style.width = Math.round(130 * size);
    O('background').style.width = Math.round(130 * size);
    document.body.style.height = Math.round((186 + sizeUpdate - sizechange) * size);
    O('background').style.height = Math.round((186 + sizeUpdate - sizechange) * size);
    allHeight = parseInt(186 + sizeUpdate - sizechange);
    document.body.style.fontSize = parseInt(9 * size);
    O('backgc').style.background = sBackg;
    O('backgc').style.top = Math.round(3 * size);
    O('backgc').style.left = Math.round(3 * size);
    O('backgc').style.width = Math.round(124 * size);
    O('backgc').style.height = Math.round((allHeight - 6) * size);
    O('blackwhite').style.top = Math.round(3 * size);
    O('blackwhite').style.left = Math.round(3 * size);
    O('blackwhite').style.width = Math.round(124 * size);
    O('blackwhite').style.height = Math.round((allHeight - 6) * size);
    O('gpuVen').style.width = parseInt(30 * size);
    O('gpuVen').style.height = parseInt(20 * size);
    if (alertGPU1 == 1) {
        O('iconAlert').style.color = sAlertIcon;
    }
    else if (alertGPU1 == 2) {
        O('iconAlert').style.color = "#808080";
    }
    O('iconAlert').innerHTML = "&#9834;";
    O('iconAlert').style.top = parseInt(2 * size);
    O('iconAlert').style.right = parseInt(5 * size);
    O('iconAlert').style.fontSize = parseInt(16 * size);
    O('gpuVen').style.top = parseInt(5 * size);
    O('gpuTitle').style.top = parseInt(3 * size);
    O('gpuNam').style.top = parseInt(15 * size);
    O('gpuClo').style.top = parseInt(26 * size);
    O('gpuTem').style.top = parseInt(26 * size);
    O('gpuUsa').style.top = parseInt(36 * size);
    O('hr1').style.top = parseInt(37 * size);
    O('memoryClo').style.top = parseInt(49 * size);
    O('used').style.top = parseInt(59 * size);
    O('free').style.top = parseInt(59 * size);
    O('total').style.top = parseInt(59 * size);
    O('memoryUse').style.top = parseInt(69 * size);
    O('memoryFre').style.top = parseInt(69 * size);
    O('memoryTot').style.top = parseInt(69 * size);
    O('memoryUsa').style.top = parseInt(79 * size);
    O('hr2').style.top = parseInt(80 * size);
    O('fanRpm').style.top = parseInt(92 * size);
    O('fanUsa').style.top = parseInt(102 * size);
    O('hr3').style.top = parseInt((103 - sizechange1) * size);
    O('shaderClo').style.top = parseInt((115 - sizechange1) * size);
    O('pcbTem').style.top = parseInt((125 - sizechange1 - sizechange2) * size);
    O('MemCon').style.top = parseInt((135 - sizechange1 - sizechange2 - sizechange3) * size);
    O('back1').style.top = parseInt(40 * size);
    O('back2').style.top = parseInt(83 * size);
    O('back3').style.top = parseInt(106 * size);
    O('bar1').style.top = parseInt(40 * size);
    O('bar2').style.top = parseInt(83 * size);
    O('bar3').style.top = parseInt(106 * size);
    O('top1').style.top = parseInt(40 * size);
    O('top2').style.top = parseInt(83 * size);
    O('top3').style.top = parseInt(106 * size);
    var sizegraph = parseInt((149 - sizechange1 - sizechange2 - sizechange3 - sizechange4 - sizechange5) * size);
    O('linesx').style.top = sizegraph;
    O('linesy').style.top = sizegraph;
    O('pergraph1').style.top = sizegraph;
    O('pergraph2').style.top = sizegraph;
    O('pergraph3').style.top = sizegraph;
    O('pergraph4').style.top = sizegraph;
    O('pergraph5').style.top = sizegraph;
    O('pergraph6').style.top = sizegraph;
    O('border').style.top = sizegraph;
    O('newUpdate').style.top = parseInt((30 * size) + sizegraph);
    var backleft = parseInt(73 * size);
    O('gpuVen').style.left = parseInt(5 * size);
    O('gpuTitle').style.left = parseInt(37 * size);
    O('gpuNam').style.left = parseInt(37 * size);
    O('gpuClo').style.left = parseInt(7 * size);
    O('gpuUsa').style.left = parseInt(7 * size);
    O('hr1').style.left = parseInt(7 * size);
    O('memoryClo').style.left = parseInt(7 * size);
    O('used').style.left = parseInt(13 * size);
    O('free').style.left = parseInt(56 * size);
    O('total').style.left = parseInt(93 * size);
    O('memoryUse').style.left = parseInt(7 * size);
    O('memoryFre').style.left = parseInt(48 * size);
    O('memoryUsa').style.left = parseInt(7 * size);
    O('hr2').style.left = parseInt(7 * size);
    O('fanRpm').style.left = parseInt(7 * size);
    O('fanUsa').style.left = parseInt(7 * size);
    O('hr3').style.left = parseInt(7 * size);
    O('shaderClo').style.left = parseInt(7 * size);
    O('pcbTem').style.left = parseInt(7 * size);
    O('MemCon').style.left = parseInt(7 * size);
    O('linesx').style.left = parseInt(7 * size);
    O('linesy').style.left = parseInt(7 * size);
    O('pergraph1').style.left = parseInt(7 * size);
    O('pergraph2').style.left = parseInt(7 * size);
    O('pergraph3').style.left = parseInt(7 * size);
    O('pergraph4').style.left = parseInt(7 * size);
    O('pergraph5').style.left = parseInt(7 * size);
    O('pergraph6').style.left = parseInt(7 * size);
    O('border').style.left = parseInt(7 * size);
    O('newUpdate').style.left = parseInt(15 * size);
    O('back1').style.left = backleft;
    O('back2').style.left = backleft;
    O('back3').style.left = backleft;
    O('bar1').style.left = backleft;
    O('bar2').style.left = backleft;
    O('bar3').style.left = backleft;
    O('top1').style.left = backleft;
    O('top2').style.left = backleft;
    O('top3').style.left = backleft;
    var backwidth = parseInt(50 * size);
    O('gpuTem').style.width = parseInt(123 * size);
    O('gpuNam').style.width = parseInt(90 * size);
    O('memoryTot').style.width = parseInt(123 * size);
    O('hr1').style.width = parseInt(116 * size);
    O('hr2').style.width = parseInt(116 * size);
    O('hr3').style.width = parseInt(116 * size);
    O('linesx').style.width = parseInt(116 * size);
    O('linesy').style.width = parseInt(116 * size);
    O('pergraph1').style.width = parseInt(116 * size);
    O('pergraph2').style.width = parseInt(116 * size);
    O('pergraph3').style.width = parseInt(116 * size);
    O('pergraph4').style.width = parseInt(116 * size);
    O('pergraph5').style.width = parseInt(116 * size);
    O('pergraph6').style.width = parseInt(116 * size);
    O('border').style.width = parseInt(115 * size)+2;
    O('back1').style.width = backwidth;
    O('back2').style.width = backwidth;
    O('back3').style.width = backwidth;
    O('top1').style.width = backwidth;
    O('top2').style.width = backwidth;
    O('top3').style.width = backwidth;
    var backheight = parseInt(6 * size);
    O('gpuNam').style.height = parseInt(10 * size);
    O('linesx').style.height = parseInt(30 * size);
    O('linesy').style.height = parseInt(30 * size);
    O('pergraph1').style.height = parseInt(30 * size);
    O('pergraph2').style.height = parseInt(30 * size);
    O('pergraph3').style.height = parseInt(30 * size);
    O('pergraph4').style.height = parseInt(30 * size);
    O('pergraph5').style.height = parseInt(30 * size);
    O('pergraph6').style.height = parseInt(30 * size);
    O('border').style.height = parseInt(30 * size)+1;
    O('back1').style.height = backheight;
    O('back2').style.height = backheight;
    O('back3').style.height = backheight;
    O('bar1').style.height = backheight;
    O('bar2').style.height = backheight;
    O('bar3').style.height = backheight;
    O('top1').style.height = backheight;
    O('top2').style.height = backheight;
    O('top3').style.height = backheight;
    O('gpuTitle').style.fontSize = parseInt(12 * size);
    O('gpuNam').style.fontSize = parseInt(9 * size);
    O('gpuClo').style.fontSize = parseInt(9 * size);
    O('gpuTem').style.fontSize = parseInt(9 * size);
    O('gpuUsa').style.fontSize = parseInt(9 * size);
    O('memoryClo').style.fontSize = parseInt(9 * size);
    O('used').style.fontSize = parseInt(9 * size);
    O('free').style.fontSize = parseInt(9 * size);
    O('total').style.fontSize = parseInt(9 * size);
    O('memoryUse').style.fontSize = parseInt(9 * size);
    O('memoryFre').style.fontSize = parseInt(9 * size);
    O('memoryTot').style.fontSize = parseInt(9 * size);
    O('memoryUsa').style.fontSize = parseInt(9 * size);
    O('fanRpm').style.fontSize = parseInt(9 * size);
    O('fanUsa').style.fontSize = parseInt(9 * size);
    O('shaderClo').style.fontSize = parseInt(9 * size);
    O('pcbTem').style.fontSize = parseInt(9 * size);
    O('MemCon').style.fontSize = parseInt(9 * size);
    O('gpuTitle').style.color = sTitle;
    O('gpuNam').style.color = sgpuName;
    O('gpuClo').style.color = sgpuClock;
    O('gpuTem').style.color = sgpuTemp;
    O('gpuUsa').style.color = sgpuUsage;
    O('memoryClo').style.color = smemoryClock;
    O('used').style.color = smemoryDeta;
    O('free').style.color = smemoryDeta;
    O('total').style.color = smemoryDeta;
    O('memoryUse').style.color = smemoryDeta;
    O('memoryFre').style.color = smemoryDeta;
    O('memoryTot').style.color = smemoryDeta;
    O('memoryUsa').style.color = smemoryUsage;
    O('fanRpm').style.color = sfanSpeed;
    O('fanUsa').style.color = sfanUsage;
    O('shaderClo').style.color = sshaderClock;
    O('pcbTem').style.color = spcbTemp;
    O('MemCon').style.color = sMemoryController;
    O('bar1').style.color = sgpuUsage;
    O('bar2').style.color = smemoryUsage;
    O('bar3').style.color = sfanUsage;
    O('pergraph1').strokecolor = sgpuTemp;
    O('pergraph1').fillcolor = sgpuTemp;
    O('pergraph2').strokecolor = sgpuUsage;
    O('pergraph2').fillcolor = sgpuUsage;
    O('pergraph3').strokecolor = smemoryUsage;
    O('pergraph3').fillcolor = smemoryUsage;
    O('pergraph4').strokecolor = sfanUsage;
    O('pergraph4').fillcolor = sfanUsage;
    O('pergraph5').strokecolor = spcbTemp;
    O('pergraph5').fillcolor = spcbTemp;
    O('pergraph6').strokecolor = sMemoryController;
    O('pergraph6').fillcolor = sMemoryController;
    O('newUpdate').style.color = "#FF0000";
    document.linkColor = "#ff0033";
    document.vlinkColor = "#ff0033";
    document.alinkColor = "#ff0033";
}

var EMPTY = "Empty";

var FILES_ONE = "File";
var FILES_MORE = "Files";
var FOLDER_ONE = "Item";
var FOLDER_MORE = "Items";

var BIN_SETTINGS = "Edit settings of recycle bin";
var BIN_SYNC = "Synchronise display";
var BIN_NO_DELETE = "The recycle bin contains nothing to delete";
var BIN_DELETE = "The recycle bin contains files for deletion";
var BIN_OPEN = "Open recycle bin (or drop elements to delete them)";

var DECIMAL_COMMA_SEPERATOR = ".";

var USE_TRANSPARENT_BACKGROUND = "Use transparent background";
var GG_COPYRIGHT = "Recycle bin &copy; 2007 by Eiskalter Engel";
var MORE_GADGETS = "More Gadgets by Eiskalter Engel";
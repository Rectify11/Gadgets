var EMPTY = "Leer";

var FILES_ONE = "Datei";
var FILES_MORE = "Dateien";
var FOLDER_ONE = "Element";
var FOLDER_MORE = "Elemente";

var BIN_SETTINGS = "Einstellungen des Papierkorbs �ndern";
var BIN_SYNC = "Anzeige aktualisieren";
var BIN_NO_DELETE = "Der Papierkorb enth�lt keine Elemente die gel�scht werden k�nnen";
var BIN_DELETE = "Es sind Elemente zum L�schen im Papierkorb vorhanden";
var BIN_OPEN = "Papierkorb �ffnen (oder Elemente hierauf zum L�schen ziehen)";

var DECIMAL_COMMA_SEPERATOR = ",";

var USE_TRANSPARENT_BACKGROUND = "Transparenten Hintergrund benutzen";
var GG_COPYRIGHT = "Papierkorb &copy; 2007 by Eiskalter Engel";
var MORE_GADGETS = "Mehr Minianwendungen von Eiskalter Engel";
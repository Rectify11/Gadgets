var EMPTY = "Vide";

var FILES_ONE = "Fichier";
var FILES_MORE = "Fichiers";
var FOLDER_ONE = "Dossier";
var FOLDER_MORE = "Dossiers";

var BIN_SETTINGS = "Modifier les propri�t�s de la corbeille";
var BIN_SYNC = "Synchroniser";
var BIN_NO_DELETE = "La corbeille ne contient pas d'�l�ments pouvant �tre suppprim�s. ";
var BIN_DELETE = "La corbeille contient des �l�ments pouvant �tre supprim�s. Gagnez de la place sur votre disque dur en effa�ant fichiers et dossiers dont vous n'avez plus l'utilit� !!! ";
var BIN_OPEN = "Ouvrir la corbeille (ou d�poser les �l�ments ici pour les supprimer)";

var DECIMAL_COMMA_SEPERATOR = ",";

var USE_TRANSPARENT_BACKGROUND = "Employer un fond transparent";
var GG_COPYRIGHT = "Corbeille &copy; 2007 de Eiskalter Engel";
var MORE_GADGETS = "Plus de Gadgets par Eiskalter Engel";